# config.py — all settings in one place

# ── PS4 IP address ────────────────────────────────────────────────────────────
# Find it: PS4 → Settings → Network → View Connection Status
PS4_IP = "192.168.29.43"   # ← change this to your PS4's IP

# ── Pico serial port ──────────────────────────────────────────────────────────
PICO_PORT     = "COM3"        # ← Device Manager > Ports (COM & LPT) → change to match
PICO_BAUDRATE = 115200

SAMPLE_RATE = 0.05            # seconds between samples when recording (20 Hz)

# ── Folders ───────────────────────────────────────────────────────────────────
LAPS_FOLDER     = "laps"      # laps/<track>/reference_lap.json
PROFILES_FOLDER = "profiles"  # profiles/<car>.json

# ── Bot behaviour ─────────────────────────────────────────────────────────────
VISION_BLEND = 0.2            # 0.0 = pure recording, 1.0 = pure vision

# ── Car profile learning ──────────────────────────────────────────────────────
LEARNING_RATE      = 0.15     # how fast profile updates each lap
LEARNING_MIN_SPEED = 60       # ignore samples below this speed (km/h)

# ── SimHub property keys (kept for reference / any legacy callers) ────────────
PROPS = {
    "track_name":     "DataCorePlugin.GameData.TrackName",
    "car_name":       "DataCorePlugin.GameData.CarModel",
    "car_class":      "DataCorePlugin.GameData.CarClass",
    "lap_number":     "DataCorePlugin.GameData.CurrentLap",
    "track_position": "DataCorePlugin.GameData.TrackPositionPercent",
    "speed_kmh":      "DataCorePlugin.GameData.SpeedKmh",
    "throttle":       "DataCorePlugin.GameData.Throttle",
    "brake":          "DataCorePlugin.GameData.Brake",
    "steering":       "DataCorePlugin.GameData.Steer",
    "gear":           "DataCorePlugin.GameData.Gear",
    "rpm":            "DataCorePlugin.GameData.Rpms",
}
