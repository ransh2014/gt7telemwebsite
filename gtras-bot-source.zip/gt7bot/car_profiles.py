# car_profiles.py — per-car scaling so one reference lap works for any car

import json
import os
from pathlib import Path
from config import PROFILES_FOLDER, LEARNING_RATE, LEARNING_MIN_SPEED
import simhub

DEFAULT = {
    "car_name":       None,
    "car_class":      None,
    "brake_scale":    1.0,    # >1 = brake harder, <1 = brake softer
    "throttle_scale": 1.0,    # >1 = more throttle, <1 = less
    "steer_scale":    1.0,    # >1 = more steering, <1 = less
    "speed_bias":     1.0,    # actual / expected speed ratio
    "laps_seen":      0,
}

def _path(car_name):
    return Path(PROFILES_FOLDER) / f"{simhub.sanitize(car_name)}.json"

def load(car_name):
    p = _path(car_name)
    if p.exists():
        with open(p) as f:
            profile = json.load(f)
        print(f"[Profile] '{car_name}' — {profile['laps_seen']} laps of data")
        return profile
    print(f"[Profile] '{car_name}' — no profile yet, using defaults")
    profile = DEFAULT.copy()
    profile["car_name"] = car_name
    return profile

def save(profile):
    os.makedirs(PROFILES_FOLDER, exist_ok=True)
    with open(_path(profile["car_name"]), "w") as f:
        json.dump(profile, f, indent=2)

def list_all():
    d = Path(PROFILES_FOLDER)
    if not d.exists():
        return
    profiles = list(d.glob("*.json"))
    if not profiles:
        return
    print("\nSaved car profiles:")
    for f in sorted(profiles):
        with open(f) as fp:
            p = json.load(fp)
        print(f"  {p.get('car_name','?'):40s} | "
              f"brake×{p['brake_scale']:.2f} "
              f"throttle×{p['throttle_scale']:.2f} "
              f"steer×{p['steer_scale']:.2f} "
              f"| {p['laps_seen']} laps")

class ProfileLearner:
    """Watches actual vs expected speed each lap and adjusts scales."""

    def __init__(self, profile):
        self.profile      = profile
        self.speed_ratios = []
        self.steer_errors = []

    def record(self, expected_speed, actual_speed, expected_steer, actual_steer):
        if actual_speed is None or expected_speed is None:
            return
        if actual_speed < LEARNING_MIN_SPEED:
            return
        if expected_speed > 5:
            self.speed_ratios.append(actual_speed / expected_speed)
        if abs(expected_steer) > 0.05 and expected_steer != 0:
            self.steer_errors.append(actual_steer / expected_steer)

    def finish_lap(self):
        if not self.speed_ratios:
            return self.profile

        avg_speed = sum(self.speed_ratios) / len(self.speed_ratios)
        p = self.profile
        lr = LEARNING_RATE

        p["speed_bias"] = p["speed_bias"] * (1 - lr) + avg_speed * lr

        # Slower than reference → more throttle
        if avg_speed < 0.95:
            p["throttle_scale"] = min(1.4, p["throttle_scale"] + lr * 0.1)
        elif avg_speed > 1.05:
            p["throttle_scale"] = max(0.7, p["throttle_scale"] - lr * 0.1)

        # Faster than reference → brake earlier
        if avg_speed > 1.05:
            p["brake_scale"] = min(1.5, p["brake_scale"] + lr * 0.1)
        elif avg_speed < 0.95:
            p["brake_scale"] = max(0.7, p["brake_scale"] - lr * 0.1)

        if self.steer_errors:
            avg_steer = sum(self.steer_errors) / len(self.steer_errors)
            p["steer_scale"] = p["steer_scale"] * (1 - lr) + avg_steer * lr
            p["steer_scale"] = max(0.6, min(1.5, p["steer_scale"]))

        p["laps_seen"] += 1
        save(p)

        print(f"\n[Profile] '{p['car_name']}' updated after lap {p['laps_seen']}:")
        print(f"  speed_bias={p['speed_bias']:.3f} | "
              f"throttle×{p['throttle_scale']:.2f} | "
              f"brake×{p['brake_scale']:.2f} | "
              f"steer×{p['steer_scale']:.2f}")
        return p
