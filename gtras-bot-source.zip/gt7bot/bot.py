# bot.py — GT7 Bot controller
# Handles Pico connection, track selection, bot playback and daytona grind.
# Run alongside gt7telem.py, or standalone if telem is already live.
#
# Usage: python bot.py

import tkinter as tk
from tkinter import ttk, scrolledtext
import threading
import time
import json
import math
from pathlib import Path

import gt7udp as telem
import car_profiles
from config import (
    PS4_IP, PICO_PORT, PICO_BAUDRATE,
    LAPS_FOLDER, SAMPLE_RATE, VISION_BLEND
)

try:
    import serial as pyserial
    SERIAL_OK = True
except ImportError:
    SERIAL_OK = False

# ─────────────────────────────────────────────────────────────────────────────
# State
# ─────────────────────────────────────────────────────────────────────────────
class State:
    pico_port    = PICO_PORT
    pico         = None          # open serial.Serial or None
    pico_ok      = False         # True only after PING handshake
    bot_running  = False
    daytona_run  = False
    track_name   = None
    car_name     = None

state = State()

# ─────────────────────────────────────────────────────────────────────────────
# Pico serial helpers
# ─────────────────────────────────────────────────────────────────────────────
def _pico_send(msg: str):
    """Write one line to Pico. Silently drops if not connected."""
    if state.pico and state.pico_ok:
        try:
            state.pico.write(f"{msg}\n".encode())
        except Exception:
            state.pico_ok = False

def send_drive(throttle: float, brake: float, steer: float):
    t = max(0.0, min(1.0, throttle))
    b = max(0.0, min(1.0, brake))
    s = max(-1.0, min(1.0, steer))
    _pico_send(f"T:{t:.3f},B:{b:.3f},S:{s:.3f}")

def send_button(name: str, hold: float = 0.1):
    _pico_send(f"BTN:{name}")
    time.sleep(hold + 0.05)

def connect_pico(port: str, log_fn) -> bool:
    """
    Open serial port and do PING/PICO_OK handshake.
    Returns True on success. Updates state.pico / state.pico_ok.
    """
    if not SERIAL_OK:
        log_fn("pyserial not installed — pip install pyserial")
        return False

    # Close any existing connection
    if state.pico:
        try: state.pico.close()
        except Exception: pass
        state.pico    = None
        state.pico_ok = False

    try:
        port_obj = pyserial.Serial(port, PICO_BAUDRATE, timeout=2)
    except Exception as e:
        log_fn(f"Cannot open {port}: {e}")
        return False

    # Drain any stale data
    time.sleep(0.3)
    port_obj.reset_input_buffer()

    # Handshake — send PING, expect PICO_OK within 2 s
    try:
        port_obj.write(b"PING\n")
        deadline = time.time() + 2.0
        response = b""
        while time.time() < deadline:
            if port_obj.in_waiting:
                response += port_obj.read(port_obj.in_waiting)
                if b"PICO_OK" in response:
                    state.pico    = port_obj
                    state.pico_ok = True
                    state.pico_port = port
                    log_fn(f"Pico connected on {port}")
                    return True
            time.sleep(0.05)
        port_obj.close()
        log_fn(f"No response from {port} — is the Pico plugged in and running code.py?")
        return False
    except Exception as e:
        try: port_obj.close()
        except Exception: pass
        log_fn(f"Handshake error: {e}")
        return False

def disconnect_pico():
    if state.pico:
        try: state.pico.close()
        except Exception: pass
    state.pico    = None
    state.pico_ok = False

# ─────────────────────────────────────────────────────────────────────────────
# Lap helpers
# ─────────────────────────────────────────────────────────────────────────────
def load_lap(track_name: str):
    """Load reference_lap.json for track. Returns samples list or None."""
    path = Path(LAPS_FOLDER) / track_name / "reference_lap.json"
    if not path.exists():
        return None
    with open(path) as f:
        data = json.load(f)
    return data.get("samples", [])

def list_tracks():
    base = Path(LAPS_FOLDER)
    if not base.exists():
        return []
    return sorted(p.name for p in base.iterdir() if p.is_dir())

def find_sample(samples, wx, wz, last_idx=0):
    """Return index of nearest sample by world coords, searching forward from last_idx."""
    best_i   = last_idx
    best_d   = float("inf")
    n        = len(samples)
    window   = 60  # only look ahead this many samples to stay on-lap
    for i in range(last_idx, min(last_idx + window, n)):
        dx = samples[i]["world_x"] - wx
        dz = samples[i]["world_z"] - wz
        d  = dx*dx + dz*dz
        if d < best_d:
            best_d = d
            best_i = i
    return best_i

def scale_sample(sample, profile):
    """Apply car profile scaling to a sample's inputs."""
    t = max(0.0, min(1.0, sample["throttle"] * profile["throttle_scale"]))
    b = max(0.0, min(1.0, sample["brake"]    * profile["brake_scale"]))
    s = max(-1.0, min(1.0, sample["steering"] * profile["steer_scale"]))
    return t, b, s

# ─────────────────────────────────────────────────────────────────────────────
# Bot playback thread
# ─────────────────────────────────────────────────────────────────────────────
def _bot_thread(log_fn, on_lap_done=None, on_stop=None):
    track = state.track_name
    samples = load_lap(track)
    if not samples:
        log_fn(f"No lap found for '{track}' — record one first")
        state.bot_running = False
        if on_stop: on_stop()
        return

    log_fn(f"Loaded '{track}' — {len(samples)} samples")

    car = telem.get("car_name") or "unknown"
    state.car_name = car
    profile = car_profiles.load(car)
    learner = car_profiles.ProfileLearner(profile)

    telem.wait_for_connection(timeout=30)
    if not telem.is_connected():
        log_fn("No telemetry — check PS4_IP in config.py")
        state.bot_running = False
        if on_stop: on_stop()
        return

    log_fn(f"Car: {car} | Running bot...")
    sample_idx = 0
    lap_count  = 0

    while state.bot_running:
        d  = telem.get_snapshot()
        wx = float(d.get("world_x") or 0)
        wz = float(d.get("world_z") or 0)
        spd = float(d.get("speed_kmh") or 0)
        exp_spd = samples[sample_idx].get("speed_kmh", spd)

        sample_idx = find_sample(samples, wx, wz, sample_idx)
        s          = samples[sample_idx]
        t, b, steer = scale_sample(s, profile)

        # Vision blend — nudge steer toward actual heading correction
        if VISION_BLEND > 0 and spd > 30:
            exp_steer = s["steering"]
            learner.record(exp_spd, spd, exp_steer, float(d.get("steering") or 0))

        send_drive(t, b, steer)

        # Advance sample index
        sample_idx = (sample_idx + 1) % len(samples)

        # Lap complete
        if sample_idx == 0:
            lap_count += 1
            log_fn(f"Lap {lap_count} complete")
            profile = learner.finish_lap()
            learner = car_profiles.ProfileLearner(profile)
            if on_lap_done: on_lap_done(lap_count)

        time.sleep(SAMPLE_RATE)

    # Stop — release all inputs
    send_drive(0, 0, 0)
    log_fn("Bot stopped.")
    if on_stop: on_stop()

# ─────────────────────────────────────────────────────────────────────────────
# Daytona grind thread
# ─────────────────────────────────────────────────────────────────────────────
DAYTONA_SEQ = [
    # After race ends: navigate back to start and relaunch
    # Adjust this sequence for your exact GT7 menu flow
    ("options",  0.5),
    ("cross",    0.8),   # confirm / select
    ("cross",    0.8),
    ("cross",    0.8),
    ("cross",    2.0),   # wait for load
    ("cross",    0.5),
    ("cross",    0.5),
]

def _daytona_thread(log_fn, on_stop=None):
    log_fn("Daytona grind started")
    lap_count = 0

    while state.daytona_run:
        # Run one bot lap
        state.bot_running = True
        track   = state.track_name
        samples = load_lap(track)
        if not samples:
            log_fn(f"No lap for '{track}'")
            break

        car     = telem.get("car_name") or "unknown"
        profile = car_profiles.load(car)
        learner = car_profiles.ProfileLearner(profile)
        idx     = 0

        while state.daytona_run:
            d   = telem.get_snapshot()
            wx  = float(d.get("world_x") or 0)
            wz  = float(d.get("world_z") or 0)
            idx = find_sample(samples, wx, wz, idx)
            t, b, steer = scale_sample(samples[idx], profile)
            send_drive(t, b, steer)
            idx = (idx + 1) % len(samples)

            if idx == 0:
                lap_count += 1
                log_fn(f"Daytona lap {lap_count} complete — navigating back")
                profile = learner.finish_lap()
                learner = car_profiles.ProfileLearner(profile)
                send_drive(0, 0, 0)
                time.sleep(1.0)
                # Navigate menus to restart
                for btn, delay in DAYTONA_SEQ:
                    if not state.daytona_run: break
                    send_button(btn)
                    time.sleep(delay)
                time.sleep(3.0)  # wait for race to load
                break

            time.sleep(SAMPLE_RATE)

    send_drive(0, 0, 0)
    state.bot_running = False
    log_fn("Daytona grind stopped.")
    if on_stop: on_stop()

# ─────────────────────────────────────────────────────────────────────────────
# GUI
# ─────────────────────────────────────────────────────────────────────────────
class BotApp(tk.Tk):
    def __init__(self):
        super().__init__()
        self.title("GT7 Bot")
        self.configure(bg="#0a0a12")
        self.attributes("-fullscreen", True)
        self.bind("<Escape>", lambda e: self.attributes("-fullscreen", False))
        self._build()
        self._start_telem()
        self.after(500, self._poll)

    # ── Build UI ──────────────────────────────────────────────────────────────
    def _build(self):
        BG  = "#0a0a12"
        PNL = "#0f0f1e"
        ACC = "#e94560"
        HI  = "#4fc3f7"
        FG  = "#c0c0e0"
        DIM = "#555566"

        # Header
        hdr = tk.Frame(self, bg="#0f3460", pady=8)
        hdr.pack(fill="x")
        tk.Label(hdr, text="GT7 BOT", fg=ACC, bg="#0f3460",
                 font=("Consolas",14,"bold")).pack(side="left", padx=16)
        self.telem_dot = tk.Label(hdr, text="● TELEM OFF", fg=DIM,
                                   bg="#0f3460", font=("Consolas",9))
        self.telem_dot.pack(side="left", padx=6)
        self.pico_dot = tk.Label(hdr, text="● PICO OFF", fg=DIM,
                                  bg="#0f3460", font=("Consolas",9))
        self.pico_dot.pack(side="left", padx=6)

        # Pico connection row
        pico_f = tk.Frame(self, bg=PNL, pady=8, padx=12)
        pico_f.pack(fill="x", pady=(6,2), padx=8)
        tk.Label(pico_f, text="PICO PORT", fg=DIM, bg=PNL,
                 font=("Consolas",8)).pack(side="left", padx=(0,6))
        self.port_var = tk.StringVar(value=PICO_PORT)
        tk.Entry(pico_f, textvariable=self.port_var, bg="#16213e", fg=FG,
                 font=("Consolas",10), width=8, relief="flat",
                 insertbackground=FG).pack(side="left", padx=(0,8))
        self.conn_btn = tk.Button(pico_f, text="Connect",
                                   command=self._toggle_pico,
                                   bg=ACC, fg="white", relief="flat",
                                   font=("Consolas",10,"bold"), padx=12)
        self.conn_btn.pack(side="left")
        self.pico_status = tk.Label(pico_f, text="Not connected", fg=DIM,
                                     bg=PNL, font=("Consolas",9))
        self.pico_status.pack(side="left", padx=10)

        # Track row
        track_f = tk.Frame(self, bg=PNL, pady=8, padx=12)
        track_f.pack(fill="x", pady=2, padx=8)
        tk.Label(track_f, text="TRACK", fg=DIM, bg=PNL,
                 font=("Consolas",8)).pack(side="left", padx=(0,6))
        self.track_var = tk.StringVar()
        self.track_dd  = ttk.Combobox(track_f, textvariable=self.track_var,
                                       width=24, state="readonly",
                                       font=("Consolas",10))
        self.track_dd.pack(side="left", padx=(0,6))
        tk.Button(track_f, text="↻", command=self._refresh_tracks,
                  bg="#16213e", fg=FG, relief="flat",
                  font=("Consolas",11), padx=6).pack(side="left")
        self.car_lbl = tk.Label(track_f, text="car: —", fg=DIM,
                                 bg=PNL, font=("Consolas",9))
        self.car_lbl.pack(side="left", padx=12)

        # Bot controls
        ctrl_f = tk.Frame(self, bg=PNL, pady=10, padx=12)
        ctrl_f.pack(fill="x", pady=2, padx=8)
        self.bot_btn = tk.Button(ctrl_f, text="▶  Start Bot",
                                  command=self._toggle_bot,
                                  bg="#16213e", fg=FG, relief="flat",
                                  font=("Consolas",11,"bold"), padx=16, pady=6)
        self.bot_btn.pack(side="left", padx=(0,8))
        self.daytona_btn = tk.Button(ctrl_f, text="🏁  Daytona Grind",
                                      command=self._toggle_daytona,
                                      bg="#16213e", fg=FG, relief="flat",
                                      font=("Consolas",11), padx=16, pady=6)
        self.daytona_btn.pack(side="left")
        self.status_lbl = tk.Label(ctrl_f, text="idle", fg=DIM,
                                    bg=PNL, font=("Consolas",9))
        self.status_lbl.pack(side="left", padx=12)

        # Lap counter
        lap_f = tk.Frame(self, bg=PNL, pady=6, padx=12)
        lap_f.pack(fill="x", pady=2, padx=8)
        for attr, label in [("lap_lbl","LAPS RUN"), ("profile_lbl","PROFILE")]:
            col = tk.Frame(lap_f, bg=PNL)
            col.pack(side="left", expand=True)
            tk.Label(col, text=label, fg=DIM, bg=PNL,
                     font=("Consolas",8)).pack()
            lbl = tk.Label(col, text="—", fg=FG, bg=PNL,
                           font=("Consolas",12,"bold"))
            lbl.pack()
            setattr(self, attr, lbl)

        # Log
        tk.Label(self, text="LOG", fg=ACC, bg=BG,
                 font=("Consolas",9,"bold")).pack(anchor="w", padx=16, pady=(8,2))
        self.log = scrolledtext.ScrolledText(self, bg="#050510", fg="#00ff88",
                                              font=("Consolas",8), relief="flat",
                                              height=14)
        self.log.pack(fill="both", expand=True, padx=8, pady=(0,8))

        self._refresh_tracks()

    # ── Telem ─────────────────────────────────────────────────────────────────
    def _start_telem(self):
        def _t():
            telem.wait_for_connection(timeout=60)
        threading.Thread(target=_t, daemon=True).start()

    # ── Poll ──────────────────────────────────────────────────────────────────
    def _poll(self):
        ok = telem.is_connected()
        self.telem_dot.config(
            text="● TELEM LIVE" if ok else "● TELEM OFF",
            fg="#2ecc71" if ok else "#555"
        )
        self.pico_dot.config(
            text="● PICO OK" if state.pico_ok else "● PICO OFF",
            fg="#4fc3f7" if state.pico_ok else "#555"
        )
        car = telem.get("car_name")
        if car:
            state.car_name = car
            self.car_lbl.config(text=f"car: {car[:28]}")
        self.after(500, self._poll)

    # ── Tracks ────────────────────────────────────────────────────────────────
    def _refresh_tracks(self):
        tracks = list_tracks()
        self.track_dd["values"] = tracks
        if tracks and not self.track_var.get():
            self.track_var.set(tracks[0])
        self.log_msg(f"{len(tracks)} track(s) found")

    # ── Pico ──────────────────────────────────────────────────────────────────
    def _toggle_pico(self):
        if state.pico_ok:
            disconnect_pico()
            self.conn_btn.config(text="Connect", bg="#e94560")
            self.pico_status.config(text="Disconnected", fg="#555")
            self.log_msg("Pico disconnected")
        else:
            port = self.port_var.get().strip()
            self.conn_btn.config(text="Connecting…", bg="#555")
            self.update_idletasks()
            def _t():
                ok = connect_pico(port, self.log_msg)
                self.after(0, self._after_connect, ok)
            threading.Thread(target=_t, daemon=True).start()

    def _after_connect(self, ok):
        if ok:
            self.conn_btn.config(text="Disconnect", bg="#2ecc71")
            self.pico_status.config(text=f"Connected on {state.pico_port}",
                                    fg="#2ecc71")
        else:
            self.conn_btn.config(text="Connect", bg="#e94560")
            self.pico_status.config(text="Failed", fg="#e74c3c")

    # ── Bot ───────────────────────────────────────────────────────────────────
    def _toggle_bot(self):
        if state.bot_running:
            state.bot_running = False
            self.bot_btn.config(text="▶  Start Bot", bg="#16213e")
            self.status_lbl.config(text="stopping…")
        else:
            track = self.track_var.get()
            if not track:
                self.log_msg("Select a track first"); return
            if not state.pico_ok:
                self.log_msg("Connect Pico first"); return
            if not telem.is_connected():
                self.log_msg("No telemetry — start GT7 first"); return
            state.track_name  = track
            state.bot_running = True
            self.bot_btn.config(text="⏹  Stop Bot", bg="#e94560")
            self.status_lbl.config(text="running")
            self._lap_count = 0
            threading.Thread(
                target=_bot_thread,
                args=(self.log_msg, self._on_lap, self._on_bot_stop),
                daemon=True
            ).start()

    def _on_lap(self, n):
        self._lap_count = n
        self.after(0, self.lap_lbl.config, {"text": str(n)})
        car = state.car_name or "—"
        self.after(0, self.profile_lbl.config, {"text": car[:18]})

    def _on_bot_stop(self):
        state.bot_running = False
        self.after(0, self.bot_btn.config,    {"text": "▶  Start Bot", "bg": "#16213e"})
        self.after(0, self.status_lbl.config, {"text": "idle"})

    # ── Daytona ───────────────────────────────────────────────────────────────
    def _toggle_daytona(self):
        if state.daytona_run:
            state.daytona_run = False
            self.daytona_btn.config(text="🏁  Daytona Grind", bg="#16213e")
            self.status_lbl.config(text="stopping…")
        else:
            track = self.track_var.get()
            if not track:
                self.log_msg("Select a track first"); return
            if not state.pico_ok:
                self.log_msg("Connect Pico first"); return
            if not telem.is_connected():
                self.log_msg("No telemetry — start GT7 first"); return
            state.track_name = track
            state.daytona_run = True
            self.daytona_btn.config(text="⏹  Stop Grind", bg="#e94560")
            self.status_lbl.config(text="grinding")
            threading.Thread(
                target=_daytona_thread,
                args=(self.log_msg, self._on_daytona_stop),
                daemon=True
            ).start()

    def _on_daytona_stop(self):
        state.daytona_run = False
        self.after(0, self.daytona_btn.config,
                   {"text": "🏁  Daytona Grind", "bg": "#16213e"})
        self.after(0, self.status_lbl.config, {"text": "idle"})

    # ── Log ───────────────────────────────────────────────────────────────────
    def log_msg(self, msg):
        self.after(0, self._log_append, msg)

    def _log_append(self, msg):
        ts = time.strftime("%H:%M:%S")
        self.log.insert("end", f"[{ts}] {msg}\n")
        self.log.see("end")


# ─────────────────────────────────────────────────────────────────────────────
if __name__ == "__main__":
    app = BotApp()
    app.mainloop()
