import tkinter as tk
from tkinter import ttk, scrolledtext
import threading
import time
import json
import math
import serial as pyserial
import numpy as np
import cv2
from pathlib import Path
try:
    import mss as mss_module
    sct = mss_module.MSS()
except:
    sct = None

import gt7udp as telem
import car_profiles
from config import PICO_PORT, PICO_BAUDRATE, LAPS_FOLDER, VISION_BLEND

# ─────────────────────────────────────────────────────────────────────────────
# Shared state
# ─────────────────────────────────────────────────────────────────────────────
class State:
    pico_port       = None
    bot_running     = False
    recording       = False
    daytona_running = False
    track_name      = None
    car_name        = None
    speed           = 0.0
    throttle        = 0.0
    brake           = 0.0
    steering        = 0.0
    rpm             = 0.0
    max_rpm         = 1.0
    gear            = 0
    tyre_fl         = 0.0
    tyre_fr         = 0.0
    tyre_rl         = 0.0
    tyre_rr         = 0.0
    telem_ok       = False
    pico_ok         = False

state = State()

# ─────────────────────────────────────────────────────────────────────────────
# Serial helpers
# ─────────────────────────────────────────────────────────────────────────────
def send(msg):
    if state.pico_port and state.pico_ok:
        try: state.pico_port.write(f"{msg}\n".encode())
        except: pass

def send_drive(t, b, s): send(f"T:{t:.3f},B:{b:.3f},S:{s:.3f}")
def send_button(name):   send(f"BTN:{name}")

# ─────────────────────────────────────────────────────────────────────────────
# Vision helpers
# ─────────────────────────────────────────────────────────────────────────────
REGION = {"top": 0, "left": 0, "width": 1280, "height": 720}

def capture():
    if sct is None: return None
    try: return cv2.cvtColor(np.array(sct.grab(REGION)), cv2.COLOR_BGRA2BGR)
    except: return None

def vision_steer(frame):
    if frame is None: return 0.0
    h, w  = frame.shape[:2]
    roi   = frame[int(h*0.45):int(h*0.85), int(w*0.1):int(w*0.9)]
    gray  = cv2.cvtColor(roi, cv2.COLOR_BGR2GRAY)
    edges = cv2.Canny(cv2.GaussianBlur(gray,(7,7),0), 40, 120)
    rw    = edges.shape[1]
    diff  = float(np.sum(edges[:,rw//2:])) - float(np.sum(edges[:,:rw//2]))
    return float(np.clip(diff/5000.0, -1.0, 1.0))

def dodge_car(frame):
    if frame is None: return 0.0
    h, w  = frame.shape[:2]
    ahead = frame[int(h*0.2):int(h*0.5), int(w*0.2):int(w*0.8)]
    hsv   = cv2.cvtColor(ahead, cv2.COLOR_BGR2HSV)
    aw    = ahead.shape[1]
    mask  = cv2.inRange(hsv, np.array([0,50,80]), np.array([180,255,255]))
    cnts,_ = cv2.findContours(mask, cv2.RETR_EXTERNAL, cv2.CHAIN_APPROX_SIMPLE)
    for cnt in cnts:
        if cv2.contourArea(cnt) > 600:
            x,_,cw,_ = cv2.boundingRect(cnt)
            return float(np.clip(-((x+cw//2)-aw//2)/(aw//2), -0.3, 0.3))
    return 0.0

# ─────────────────────────────────────────────────────────────────────────────
# Lap reference helpers — track_position matching (0.0–1.0)
# ─────────────────────────────────────────────────────────────────────────────
def load_lap(track_name):
    safe = telem.sanitize(track_name)
    f    = Path(LAPS_FOLDER) / safe / "reference_lap.json"
    if not f.exists(): return None, None
    with open(f) as fp: data = json.load(fp)
    print(f"[OK] Lap loaded: {track_name} — {data['total_samples']} samples")
    return data["samples"], data.get("reference_car")

def find_sample(samples, wx, wz, track_pos=0.0):
    """
    Match nearest sample by world X/Z (accurate, used when UDP telemetry active).
    Falls back to track_position metres if world coords are all zero (legacy laps).
    """
    if not samples:
        return None
    has_coords = (wx != 0.0 or wz != 0.0) and any(
        s.get("world_x", 0.0) != 0.0 or s.get("world_z", 0.0) != 0.0
        for s in samples[:20]
    )
    if has_coords:
        best, best_d = samples[0], float("inf")
        for s in samples:
            dx = s.get("world_x", 0.0) - wx
            dz = s.get("world_z", 0.0) - wz
            d  = dx*dx + dz*dz
            if d < best_d:
                best_d, best = d, s
        return best
    best, best_d = samples[0], float("inf")
    for s in samples:
        d = abs(s.get("track_position", 0.0) - track_pos)
        if d < best_d:
            best_d, best = d, s
    return best

def scale(sample, profile):
    t = float(np.clip(float(sample.get("throttle", 0)) * profile["throttle_scale"], 0, 1))
    b = float(np.clip(float(sample.get("brake",    0)) * profile["brake_scale"],    0, 1))
    s = float(np.clip(float(sample.get("steering", 0)) * profile["steer_scale"],   -1, 1))
    return t, b, s

# ─────────────────────────────────────────────────────────────────────────────
# Track/Car dialog
# ─────────────────────────────────────────────────────────────────────────────
class TrackCarDialog(tk.Toplevel):
    def __init__(self, parent):
        super().__init__(parent)
        self.title("Track & Car")
        self.configure(bg="#1a1a2e")
        self.resizable(False, False)
        self.result = None
        self.grab_set()
        bg = "#1a1a2e"; fg = "#c0c0e0"; accent = "#e94560"
        tk.Label(self, text="Track name:", fg=fg, bg=bg,
                 font=("Segoe UI",11)).grid(row=0,column=0,padx=16,pady=(16,4),sticky="w")
        self.track_var = tk.StringVar()
        tk.Entry(self, textvariable=self.track_var, width=30,
                 bg="#0f3460", fg="white", insertbackground="white",
                 relief="flat", font=("Segoe UI",11)).grid(row=0,column=1,padx=(0,16),pady=(16,4))
        tk.Label(self, text="Car name:", fg=fg, bg=bg,
                 font=("Segoe UI",11)).grid(row=1,column=0,padx=16,pady=4,sticky="w")
        self.car_var = tk.StringVar()
        tk.Entry(self, textvariable=self.car_var, width=30,
                 bg="#0f3460", fg="white", insertbackground="white",
                 relief="flat", font=("Segoe UI",11)).grid(row=1,column=1,padx=(0,16),pady=4)
        bf = tk.Frame(self, bg=bg)
        bf.grid(row=2, column=0, columnspan=2, pady=12)
        tk.Button(bf, text="Start Recording", bg=accent, fg="white",
                  font=("Segoe UI",11,"bold"), relief="flat", padx=12, pady=6,
                  command=self._ok).pack(side="left", padx=6)
        tk.Button(bf, text="Cancel", bg="#333", fg=fg,
                  font=("Segoe UI",11), relief="flat", padx=12, pady=6,
                  command=self.destroy).pack(side="left", padx=6)

    def _ok(self):
        track = self.track_var.get().strip()
        car   = self.car_var.get().strip() or "Unknown Car"
        if not track: return
        self.result = (track, car)
        self.destroy()

# ─────────────────────────────────────────────────────────────────────────────
# Main App
# ─────────────────────────────────────────────────────────────────────────────
class App(tk.Tk):
    def __init__(self):
        super().__init__()
        self.title("GT7 Bot")
        self.configure(bg="#0d0d1a")
        self.state("zoomed")   # start maximised (Windows)
        self._fullscreen = False
        self.bind("<F11>", self._toggle_fullscreen)
        self.bind("<Escape>", self._exit_fullscreen)

        style = ttk.Style(self)
        style.theme_use("clam")
        style.configure("TNotebook",     background="#0d0d1a", borderwidth=0)
        style.configure("TNotebook.Tab", background="#16213e", foreground="#a0a0c0",
                        padding=[20,10], font=("Segoe UI",11))
        style.map("TNotebook.Tab",
                  background=[("selected","#0f3460")],
                  foreground=[("selected","#e94560")])
        style.configure("TFrame", background="#0d0d1a")

        nb = ttk.Notebook(self)
        nb.pack(fill="both", expand=True, padx=8, pady=8)

        self.race_tab = RaceTab(nb, self)
        self.nav_tab  = NavTab(nb)
        nb.add(self.race_tab, text="  🏎  Race  ")
        nb.add(self.nav_tab,  text="  🎮  PS4 Nav  ")

        self.protocol("WM_DELETE_WINDOW", self._on_close)
        self.after(500, self.race_tab.poll)

    def _toggle_fullscreen(self, e=None):
        self._fullscreen = not self._fullscreen
        self.attributes("-fullscreen", self._fullscreen)

    def _exit_fullscreen(self, e=None):
        if self._fullscreen:
            self._fullscreen = False
            self.attributes("-fullscreen", False)

    def _on_close(self):
        state.bot_running     = False
        state.daytona_running = False
        state.recording       = False
        if state.pico_port:
            try: state.pico_port.close()
            except: pass
        self.destroy()

# ─────────────────────────────────────────────────────────────────────────────
# Race Tab
# ─────────────────────────────────────────────────────────────────────────────
class RaceTab(ttk.Frame):
    def __init__(self, parent, app):
        super().__init__(parent)
        self.app = app
        self.configure(style="TFrame")
        self._build()

    def _build(self):
        bg = "#0d0d1a"; fg = "#c0c0e0"; accent = "#e94560"
        hi = "#4fc3f7"

        # ── Top bar: status + connect ──
        top = tk.Frame(self, bg="#0f3460", pady=8)
        top.pack(fill="x", padx=6, pady=(6,4))

        self.sh_dot = tk.Label(top, text="●", fg="#333", bg="#0f3460", font=("Segoe UI",14))
        self.sh_dot.pack(side="left", padx=(12,3))
        tk.Label(top, text="GT7 UDP", fg=fg, bg="#0f3460",
                 font=("Segoe UI",10)).pack(side="left", padx=(0,16))
        self.pk_dot = tk.Label(top, text="●", fg="#333", bg="#0f3460", font=("Segoe UI",14))
        self.pk_dot.pack(side="left", padx=(0,3))
        tk.Label(top, text="Pico", fg=fg, bg="#0f3460",
                 font=("Segoe UI",10)).pack(side="left")
        tk.Label(top, text="F11 = Fullscreen", fg="#555", bg="#0f3460",
                 font=("Segoe UI",9)).pack(side="left", padx=20)
        tk.Button(top, text="⚡ Connect", command=self.connect,
                  bg=accent, fg="white", relief="flat",
                  font=("Segoe UI",10,"bold"), padx=14, pady=4
                  ).pack(side="right", padx=12)

        # ── Main content: left panel + right panel ──
        content = tk.Frame(self, bg=bg)
        content.pack(fill="both", expand=True, padx=6, pady=4)

        left  = tk.Frame(content, bg=bg)
        left.pack(side="left", fill="both", expand=True)
        right = tk.Frame(content, bg=bg, width=320)
        right.pack(side="right", fill="y", padx=(4,0))
        right.pack_propagate(False)

        # ── LEFT: Track selector + big telemetry ──
        tr = tk.Frame(left, bg="#16213e", pady=6)
        tr.pack(fill="x", pady=(0,4))
        tk.Label(tr, text="Track:", fg=fg, bg="#16213e",
                 font=("Segoe UI",11)).pack(side="left", padx=(10,4))
        self.track_var = tk.StringVar(value="— select track —")
        self.track_dd  = ttk.Combobox(tr, textvariable=self.track_var,
                                       state="readonly", width=30,
                                       font=("Segoe UI",11))
        self.track_dd.pack(side="left", padx=4)
        tk.Button(tr, text="↺ Refresh", command=self.refresh_tracks,
                  bg="#0f3460", fg=fg, relief="flat",
                  font=("Segoe UI",9), padx=8).pack(side="left", padx=4)
        self.car_lbl = tk.Label(tr, text="Car: —", fg="#888", bg="#16213e",
                                 font=("Segoe UI",10))
        self.car_lbl.pack(side="right", padx=12)
        self.refresh_tracks()

        # Big speed display
        speed_f = tk.Frame(left, bg="#0a0a18", pady=10)
        speed_f.pack(fill="x", pady=4)
        self.speed_big = tk.Label(speed_f, text="0", fg=hi, bg="#0a0a18",
                                   font=("Consolas",56,"bold"))
        self.speed_big.pack(side="left", padx=20)
        tk.Label(speed_f, text="km/h", fg="#555", bg="#0a0a18",
                 font=("Segoe UI",14)).pack(side="left", pady=(20,0))

        self.gear_big = tk.Label(speed_f, text="N", fg="#f39c12", bg="#0a0a18",
                                  font=("Consolas",56,"bold"))
        self.gear_big.pack(side="right", padx=20)
        tk.Label(speed_f, text="gear", fg="#555", bg="#0a0a18",
                 font=("Segoe UI",14)).pack(side="right", pady=(20,0))

        # RPM bar
        rpm_f = tk.Frame(left, bg=bg)
        rpm_f.pack(fill="x", pady=(0,4))
        tk.Label(rpm_f, text="RPM", fg="#888", bg=bg,
                 font=("Segoe UI",9), width=6).pack(side="left", padx=6)
        self.rpm_var = tk.DoubleVar()
        self.rpm_bar = ttk.Progressbar(rpm_f, variable=self.rpm_var,
                                        maximum=100, length=400, mode="determinate")
        self.rpm_bar.pack(side="left", fill="x", expand=True, padx=4)
        self.rpm_lbl = tk.Label(rpm_f, text="0", fg="#e74c3c", bg=bg,
                                 font=("Consolas",10), width=8)
        self.rpm_lbl.pack(side="left")

        # Throttle bar
        thr_f = tk.Frame(left, bg=bg)
        thr_f.pack(fill="x", pady=2)
        tk.Label(thr_f, text="R2", fg="#888", bg=bg,
                 font=("Segoe UI",9), width=6).pack(side="left", padx=6)
        self.thr_var = tk.DoubleVar()
        self.thr_bar = ttk.Progressbar(thr_f, variable=self.thr_var,
                                        maximum=100, length=400, mode="determinate")
        self.thr_bar.pack(side="left", fill="x", expand=True, padx=4)
        self.thr_lbl = tk.Label(thr_f, text="0%", fg="#2ecc71", bg=bg,
                                 font=("Consolas",10), width=8)
        self.thr_lbl.pack(side="left")

        # Brake bar
        brk_f = tk.Frame(left, bg=bg)
        brk_f.pack(fill="x", pady=2)
        tk.Label(brk_f, text="L2", fg="#888", bg=bg,
                 font=("Segoe UI",9), width=6).pack(side="left", padx=6)
        self.brk_var = tk.DoubleVar()
        self.brk_bar = ttk.Progressbar(brk_f, variable=self.brk_var,
                                        maximum=100, length=400, mode="determinate")
        self.brk_bar.pack(side="left", fill="x", expand=True, padx=4)
        self.brk_lbl = tk.Label(brk_f, text="0%", fg="#e74c3c", bg=bg,
                                 font=("Consolas",10), width=8)
        self.brk_lbl.pack(side="left")

        # Tyre temps
        tyre_f = tk.LabelFrame(left, text=" Tyre Temps (°C) ", fg=accent,
                                bg=bg, font=("Segoe UI",9))
        tyre_f.pack(fill="x", pady=6, padx=4)
        for label, attr in [("FL","tyre_fl"),("FR","tyre_fr"),("RL","tyre_rl"),("RR","tyre_rr")]:
            col = tk.Frame(tyre_f, bg=bg)
            col.pack(side="left", expand=True, padx=10, pady=4)
            tk.Label(col, text=label, fg="#888", bg=bg, font=("Segoe UI",9)).pack()
            lbl = tk.Label(col, text="—", fg=hi, bg=bg, font=("Consolas",13,"bold"))
            lbl.pack()
            setattr(self, f"_{attr}_lbl", lbl)

        # Buttons
        bf = tk.Frame(left, bg=bg)
        bf.pack(fill="x", pady=8)

        self.rec_btn = tk.Button(bf, text="⏺  Record Lap",
                                  command=self.toggle_record,
                                  bg="#16213e", fg=fg, relief="flat",
                                  font=("Segoe UI",11,"bold"), padx=16, pady=10)
        self.rec_btn.pack(side="left", padx=4)

        self.bot_btn = tk.Button(bf, text="▶  Start Bot",
                                  command=self.toggle_bot,
                                  bg=accent, fg="white", relief="flat",
                                  font=("Segoe UI",11,"bold"), padx=16, pady=10)
        self.bot_btn.pack(side="left", padx=4)

        self.daytona_btn = tk.Button(bf, text="🏁  Daytona Grind",
                                      command=self.toggle_daytona,
                                      bg="#f39c12", fg="white", relief="flat",
                                      font=("Segoe UI",11,"bold"), padx=16, pady=10)
        self.daytona_btn.pack(side="left", padx=4)

        # ── RIGHT: Log ──
        tk.Label(right, text="LOG", fg=accent, bg=bg,
                 font=("Segoe UI",10,"bold")).pack(anchor="w", padx=4, pady=(4,0))
        self.log = scrolledtext.ScrolledText(right, bg="#050510", fg="#00ff88",
                                              font=("Consolas",9), relief="flat")
        self.log.pack(fill="both", expand=True, padx=4, pady=4)

    # ── Helpers ──────────────────────────────────────────────────────────────
    def log_msg(self, msg):
        """Thread-safe — can be called from any thread."""
        self.after(0, self._log_append, msg)

    def _log_append(self, msg):
        ts = time.strftime("%H:%M:%S")
        self.log.insert("end", f"[{ts}] {msg}\n")
        self.log.see("end")

    def refresh_tracks(self):
        d = Path(LAPS_FOLDER)
        if not d.exists():
            self.track_dd["values"] = []
            return
        tracks = []
        for folder in sorted(d.iterdir()):
            lf = folder / "reference_lap.json"
            if lf.exists():
                try:
                    with open(lf) as fp: data = json.load(fp)
                    tracks.append(data["track_name"])
                except: pass
        self.track_dd["values"] = tracks
        if tracks and self.track_var.get() == "— select track —":
            self.track_var.set(tracks[0])

    # ── Connect ───────────────────────────────────────────────────────────────
    def connect(self):
        threading.Thread(target=self._connect_thread, daemon=True).start()

    def _connect_thread(self):
        # ── GT7 UDP telemetry ──
        self.log_msg("Connecting to GT7 UDP telemetry...")
        name = telem.wait_for_connection(timeout=60)
        if name is not None:
            state.telem_ok  = True
            state.track_name = name
            state.car_name   = telem.get("car_name") or "Unknown"
            src = telem._source or "udp"
            self.log_msg(f"GT7 telemetry OK via {src}")
        else:
            self.log_msg("GT7 telemetry FAILED — enable GT7 Telemetry in game settings")

        # ── Pico ──
        self.log_msg(f"Connecting to Pico on {PICO_PORT}...")
        try:
            port = pyserial.Serial(PICO_PORT, PICO_BAUDRATE, timeout=1)
            state.pico_port = port
            state.pico_ok   = True
            self.log_msg("Pico OK — controller ready")
        except Exception as e:
            self.log_msg(f"Pico FAILED: {e} — check PICO_PORT in config.py")

    # ── Record ────────────────────────────────────────────────────────────────
    def toggle_record(self):
        if state.recording:
            state.recording = False
            self.rec_btn.config(text="⏺  Record Lap")
        else:
            if not state.telem_ok:
                self.log_msg("Connect to GT7 telemetry first.")
                return
            dialog = TrackCarDialog(self)
            self.wait_window(dialog)
            if not dialog.result: return
            track, car = dialog.result
            state.track_name = track
            state.car_name   = car
            telem.set_track(track)
            telem.set_car(car)
            telem.reset_lap()
            state.recording = True
            self.rec_btn.config(text="⏹  Stop Recording")
            threading.Thread(target=self._record_thread, daemon=True).start()

    def _record_thread(self):
        from config import SAMPLE_RATE
        self.log_msg("Recording — cross the start line to begin...")
        cur_lap = telem.get_int("lap_number") or 0

        # Wait for lap increment (start line crossing)
        while state.recording:
            lap = telem.get_int("lap_number")
            if lap and lap > cur_lap:
                telem.reset_lap()
                cur_lap = lap
                self.log_msg(f"Lap {lap} — RECORDING!")
                break
            time.sleep(0.05)

        samples  = []
        start_t  = time.time()
        prev_lap = cur_lap

        while state.recording:
            data    = telem.get_snapshot()
            elapsed = round(time.time() - start_t, 3)
            lap     = int(data.get("lap_number") or prev_lap)
            if lap > prev_lap:
                self.log_msg(f"Lap complete — {len(samples)} samples")
                break
            prev_lap = lap

            try: tp = float(data.get("track_position") or 0)
            except: tp = 0.0
            try: wx = float(data.get("world_x") or 0)
            except: wx = 0.0
            try: wz = float(data.get("world_z") or 0)
            except: wz = 0.0

            samples.append({
                "t":              elapsed,
                "world_x":        round(wx, 3),
                "world_z":        round(wz, 3),
                "track_position": round(tp, 3),
                "speed_kmh":      round(float(data.get("speed_kmh") or 0), 2),
                "throttle":       round(float(data.get("throttle") or 0), 4),
                "brake":          round(float(data.get("brake") or 0), 4),
                "steering":       round(float(data.get("steering") or 0), 4),
                "gear":           int(data.get("gear") or 0),
            })
            time.sleep(SAMPLE_RATE)

        state.recording = False
        self.after(0, lambda: self.rec_btn.config(text="⏺  Record Lap"))
        if samples and state.track_name:
            self._save_lap(samples)

    def _save_lap(self, samples):
        from config import SAMPLE_RATE
        import math as _math
        has_coords = any(s.get("world_x", 0) != 0 or s.get("world_z", 0) != 0 for s in samples)
        if has_coords:
            lap_dist = sum(
                _math.sqrt((samples[i]["world_x"] - samples[i-1]["world_x"])**2 +
                           (samples[i]["world_z"] - samples[i-1]["world_z"])**2)
                for i in range(1, len(samples))
            )
        else:
            lap_dist = sum(
                float(samples[i-1].get("speed_kmh", 0)) / 3.6 * SAMPLE_RATE
                for i in range(1, len(samples))
            )
        if lap_dist < 1.0: lap_dist = 1.0

        track = state.track_name
        safe  = telem.sanitize(track)
        d     = Path(LAPS_FOLDER) / safe
        d.mkdir(parents=True, exist_ok=True)
        src = telem._source or "gt7udp"
        with open(d / "reference_lap.json", "w") as f:
            json.dump({
                "track_name":     track,
                "track_folder":   safe,
                "reference_car":  state.car_name,
                "telem_source":   src,
                "sample_rate":    SAMPLE_RATE,
                "total_samples":  len(samples),
                "lap_distance_m": round(lap_dist, 1),
                "samples":        samples,
            }, f, indent=2)
        tag = "real coords" if has_coords else "estimated"
        self.log_msg(f"Saved: laps/{safe}/reference_lap.json ({lap_dist:.0f}m, {tag})")
        self.refresh_tracks()

    # ── Bot ───────────────────────────────────────────────────────────────────
    def toggle_bot(self):
        if state.bot_running:
            state.bot_running = False
            self.bot_btn.config(text="▶  Start Bot", bg="#e94560")
        else:
            if not state.pico_ok:
                self.log_msg("Connect to Pico first."); return
            if not state.telem_ok:
                self.log_msg("Connect to GT7 telemetry first."); return
            sel = self.track_var.get()
            if not sel or sel == "— select track —":
                self.log_msg("Select a track from the dropdown."); return
            state.track_name = sel
            telem.set_track(sel)
            samples, _ = load_lap(sel)
            if not samples:
                self.log_msg(f"No lap recorded for {sel}. Record one first."); return
            state.bot_running = True
            self.bot_btn.config(text="⏹  Stop Bot", bg="#555")
            threading.Thread(target=self._bot_thread, args=(samples,), daemon=True).start()

    def _bot_thread(self, samples):
        self.log_msg("Bot starting...")
        car     = state.car_name or "Unknown"
        profile = car_profiles.load(car)
        profile["car_name"] = car
        learner = car_profiles.ProfileLearner(profile)
        cur_lap = telem.get_int("lap_number") or 0
        stuck   = 0
        last_dodge_t = 0.0

        while state.bot_running:
            wx        = telem.get_float("world_x") or 0.0
            wz        = telem.get_float("world_z") or 0.0
            track_pos = telem.get_float("track_position") or 0.0
            spd       = telem.get_float("speed_kmh") or 0.0
            new_lap   = telem.get_int("lap_number") or cur_lap

            if new_lap > cur_lap:
                self.log_msg(f"Lap {new_lap} — updating car profile...")
                profile = learner.finish_lap()
                learner = car_profiles.ProfileLearner(profile)
                telem.reset_lap()
                cur_lap = new_lap

            sample = find_sample(samples, wx, wz, track_pos)
            if sample is None:
                time.sleep(0.033)
                continue
            t, b, ref_s = scale(sample, profile)

            frame   = capture()
            vis     = vision_steer(frame)
            dodge   = dodge_car(frame)
            final_s = float(np.clip(ref_s*(1-VISION_BLEND) + vis*VISION_BLEND + dodge, -1.0, 1.0))

            if spd < 4.0:
                stuck += 1
            else:
                stuck = 0

            if stuck > 20:
                self.log_msg("Stuck — recovering...")
                send_drive(0, 1.0, 0.3)
                time.sleep(2.0)
                stuck = 0
                continue

            if abs(dodge) > 0.1 and time.time() - last_dodge_t > 2.0:
                send_button("circle")
                last_dodge_t = time.time()

            learner.record(float(sample.get("speed_kmh", 0)), spd,
                           float(sample.get("steering", 0)), final_s)
            send_drive(t, b, final_s)

            state.speed    = spd
            state.throttle = t
            state.brake    = b
            state.steering = final_s
            time.sleep(0.033)

        send_drive(0, 0, 0)
        self.log_msg("Bot stopped.")
        self.after(0, lambda: self.bot_btn.config(text="▶  Start Bot", bg="#e94560"))

    # ── Daytona Grind ─────────────────────────────────────────────────────────
    def toggle_daytona(self):
        if state.daytona_running:
            state.daytona_running = False
            self.daytona_btn.config(text="🏁  Daytona Grind", bg="#f39c12")
            send_drive(0, 0, 0)
            self.log_msg("Daytona grind stopped.")
        else:
            if not state.pico_ok:
                self.log_msg("Connect to Pico first."); return
            state.daytona_running = True
            self.daytona_btn.config(text="⏹  Stop Grind", bg="#555")
            threading.Thread(target=self._daytona_thread, daemon=True).start()

    def _daytona_thread(self):
        STEER_LEAN   = 0.04
        RACE_END_SPD = 5.0
        RACE_END_SEC = 6
        self.log_msg("Phase 1: Daytona — full throttle!")
        low_spd_since = None
        race_started  = False

        while state.daytona_running:
            spd = telem.get_float("speed_kmh") or 0.0
            state.speed = spd
            send_drive(1.0, 0.0, STEER_LEAN)
            if spd > 20: race_started = True
            if race_started:
                # Only count race-end when telemetry is live (avoids false trigger on dropout)
                if spd < RACE_END_SPD and telem.is_connected():
                    if low_spd_since is None: low_spd_since = time.time()
                    elif time.time() - low_spd_since > RACE_END_SEC:
                        self.log_msg("Race end detected — navigating menus...")
                        break
                else:
                    low_spd_since = None
            time.sleep(0.05)

        if not state.daytona_running: return
        send_drive(0, 0, 0)
        self._daytona_navigate()

    def _daytona_navigate(self):
        def wait(secs, msg=None):
            if msg: self.log_msg(msg)
            dl = time.time() + secs
            while time.time() < dl:
                if not state.daytona_running: return
                time.sleep(0.1)
        def tap(btn, times=1, gap=0.8):
            for _ in range(times):
                if not state.daytona_running: return
                send_button(btn); time.sleep(gap)

        wait(5,  "Waiting for results screen...")
        tap("cross",  times=6, gap=1.2)
        wait(3,  "Clearing bonus screens...")
        tap("cross",  times=4, gap=1.0)
        wait(2)
        tap("down",   times=1, gap=0.3)
        tap("cross",  times=1, gap=0.3)
        wait(12, "Waiting for race reload...")
        if state.daytona_running:
            self.log_msg("Restarted — back to full throttle!")
            threading.Thread(target=self._daytona_thread, daemon=True).start()

    # ── Phase stubs (Phase 1.5 / 2 / 3) ─────────────────────────────────────
    def _phase1_5_playback(self):
        raise NotImplementedError("Phase 1.5 — implement after Pico confirmed working")

    def _phase2_slide_correction(self, heading, velocity_dir):
        raise NotImplementedError("Phase 2 — slide detection")

    def _phase2_spin_recovery(self):
        raise NotImplementedError("Phase 2 — spin recovery / triangle reverse")

    def _phase2_pit_routing(self, manual_override=False):
        raise NotImplementedError("Phase 2 — automated pit stops")

    # ── Poll (4 Hz UI refresh) ────────────────────────────────────────────────
    def poll(self):
        self.sh_dot.config(fg="#2ecc71" if state.telem_ok else "#333")
        self.pk_dot.config(fg="#2ecc71" if state.pico_ok  else "#333")

        if state.car_name:
            self.car_lbl.config(text=f"Car: {state.car_name}")

        self.speed_big.config(text=f"{state.speed:.0f}")
        self.gear_big.config(text=str(state.gear) if state.gear > 0 else "N")

        self.rpm_var.set(min(100, (state.rpm / max(state.max_rpm, 1)) * 100))
        self.rpm_lbl.config(text=f"{state.rpm:.0f}")
        self.thr_var.set(state.throttle * 100)
        self.thr_lbl.config(text=f"{state.throttle*100:.0f}%")
        self.brk_var.set(state.brake * 100)
        self.brk_lbl.config(text=f"{state.brake*100:.0f}%")

        for attr, val in [("tyre_fl", state.tyre_fl), ("tyre_fr", state.tyre_fr),
                           ("tyre_rl", state.tyre_rl), ("tyre_rr", state.tyre_rr)]:
            lbl = getattr(self, f"_{attr}_lbl")
            if val > 0:
                col = "#2ecc71" if val < 80 else "#f39c12" if val < 100 else "#e74c3c"
                lbl.config(text=f"{val:.0f}°", fg=col)

        # Pull live telemetry when bot/daytona are not running
        if state.telem_ok and not state.bot_running and not state.daytona_running:
            d = telem.get_snapshot()
            try: state.speed    = float(d.get("speed_kmh") or 0)
            except: pass
            try: state.throttle = float(d.get("throttle") or 0)
            except: pass
            try: state.brake    = float(d.get("brake") or 0)
            except: pass
            try: state.rpm      = float(d.get("rpm") or 0)
            except: pass
            try: state.max_rpm  = float(d.get("max_rpm") or 1)
            except: pass
            try: state.gear     = int(d.get("gear") or 0)
            except: pass
            try: state.tyre_fl  = float(d.get("tyre_temp_fl") or 0)
            except: pass
            try: state.tyre_fr  = float(d.get("tyre_temp_fr") or 0)
            except: pass
            try: state.tyre_rl  = float(d.get("tyre_temp_rl") or 0)
            except: pass
            try: state.tyre_rr  = float(d.get("tyre_temp_rr") or 0)
            except: pass

        self.after(250, self.poll)


# ─────────────────────────────────────────────────────────────────────────────
# PS4 Nav Tab
# ─────────────────────────────────────────────────────────────────────────────
class NavTab(ttk.Frame):
    def __init__(self, parent):
        super().__init__(parent)
        self.configure(style="TFrame")
        self._build()

    def _build(self):
        bg = "#0d0d1a"; fg = "#c0c0e0"; accent = "#e94560"

        tk.Label(self, text="PS4 Navigation Controller", fg=accent, bg=bg,
                 font=("Segoe UI",14,"bold")).pack(pady=(16,2))
        tk.Label(self, text="Click buttons to send inputs to PS4  |  Works anytime Pico is connected",
                 fg="#555", bg=bg, font=("Segoe UI",9)).pack(pady=(0,16))

        main = tk.Frame(self, bg=bg)
        main.pack(expand=True)

        # ── Left: D-pad + system ──
        left = tk.Frame(main, bg=bg)
        left.grid(row=0, column=0, padx=40, pady=10)

        tk.Label(left, text="D-Pad", fg="#555", bg=bg,
                 font=("Segoe UI",9)).grid(row=0, column=0, columnspan=3, pady=(0,4))
        self._btn(left, "▲",      "#2c3e50", lambda: send_button("up"),      1, 1, w=5, h=2)
        self._btn(left, "◄",      "#2c3e50", lambda: send_button("left"),    2, 0, w=5, h=2)
        self._btn(left, "●",      "#1a1a2e", lambda: None,                    2, 1, w=5, h=2)
        self._btn(left, "►",      "#2c3e50", lambda: send_button("right"),   2, 2, w=5, h=2)
        self._btn(left, "▼",      "#2c3e50", lambda: send_button("down"),    3, 1, w=5, h=2)

        sys_f = tk.Frame(left, bg=bg)
        sys_f.grid(row=4, column=0, columnspan=3, pady=(20,0))
        self._btn(sys_f, "OPTIONS", "#2c3e50", lambda: send_button("options"), 0, 0, w=9, h=2)
        self._btn(sys_f, "PS",      "#e94560", lambda: send_button("ps"),      0, 1, w=7, h=2)
        self._btn(sys_f, "SHARE",   "#2c3e50", lambda: send_button("share"),   0, 2, w=9, h=2)

        # ── Right: Face buttons ──
        right = tk.Frame(main, bg=bg)
        right.grid(row=0, column=1, padx=40, pady=10)

        tk.Label(right, text="Buttons", fg="#555", bg=bg,
                 font=("Segoe UI",9)).grid(row=0, column=0, columnspan=3, pady=(0,4))
        self._btn(right, "△", "#1abc9c", lambda: send_button("triangle"), 1, 1, w=5, h=2)
        self._btn(right, "□", "#9b59b6", lambda: send_button("square"),   2, 0, w=5, h=2)
        self._btn(right, "○", "#e74c3c", lambda: send_button("circle"),   2, 2, w=5, h=2)
        self._btn(right, "✕", "#3498db", lambda: send_button("cross"),    3, 1, w=5, h=2)

        # ── Shoulder buttons ──
        sh = tk.Frame(main, bg=bg)
        sh.grid(row=1, column=0, columnspan=2, pady=20)

        tk.Label(sh, text="Shoulder / Triggers", fg="#555", bg=bg,
                 font=("Segoe UI",9)).grid(row=0, column=0, columnspan=4, pady=(0,6))
        self._btn(sh, "L2\n(Brake)",    "#c0392b",
                  lambda: (send_drive(0, 1.0, 0), threading.Timer(0.3, lambda: send_drive(0,0,0)).start()),
                  1, 0, w=10, h=3)
        self._btn(sh, "L1",             "#2c3e50", lambda: send_button("l1"), 1, 1, w=10, h=3)
        self._btn(sh, "R1",             "#2c3e50", lambda: send_button("r1"), 1, 2, w=10, h=3)
        self._btn(sh, "R2\n(Throttle)", "#27ae60",
                  lambda: (send_drive(1.0, 0, 0), threading.Timer(0.3, lambda: send_drive(0,0,0)).start()),
                  1, 3, w=10, h=3)

    def _btn(self, parent, text, color, cmd, row, col, w=5, h=2, fg="white"):
        b = tk.Button(parent, text=text, bg=color, fg=fg,
                      font=("Segoe UI",10,"bold"),
                      width=w, height=h,
                      relief="flat", activebackground="#666",
                      command=cmd)
        b.grid(row=row, column=col, padx=4, pady=4)


# ─────────────────────────────────────────────────────────────────────────────
if __name__ == "__main__":
    app = App()
    app.mainloop()
