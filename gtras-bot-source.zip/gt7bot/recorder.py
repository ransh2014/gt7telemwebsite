# recorder.py — record a reference lap via GT7 direct UDP
#
# Usage:
#   python recorder.py
#
# Saves to laps/<track>/reference_lap.json
# Compatible with gui.py bot playback.

import json
import time
import math
from pathlib import Path

import gt7udp as telem
from config import SAMPLE_RATE, LAPS_FOLDER

def _f(v):
    try: return round(float(v), 4)
    except: return 0.0

def _i(v):
    try: return int(v)
    except: return 0

def ask(prompt, default=""):
    val = input(prompt).strip()
    return val if val else default

def list_saved():
    d = Path(LAPS_FOLDER)
    if not d.exists(): return
    laps = list(d.rglob("reference_lap.json"))
    if not laps: return
    print("\nAlready recorded:")
    for f in sorted(laps):
        try:
            with open(f) as fp: data = json.load(fp)
            print(f"  {data['track_name']:45s} | {data.get('reference_car','?')} | {data.get('total_samples',0)} samples")
        except: pass

if __name__ == "__main__":
    print("=" * 55)
    print("  GT7 Lap Recorder")
    print("=" * 55)
    list_saved()
    print()

    track = ask("Track name (e.g. Monza, Spa, Daytona): ")
    car   = ask("Car name   (e.g. Porsche 911 GR4):     ", "Unknown Car")
    if not track:
        print("Track name required."); exit()

    telem.set_track(track)
    telem.set_car(car)
    if not telem.wait_for_connection():
        print("Could not connect. Exiting."); exit()
    telem.reset_lap()

    print(f"\nTrack : {track}")
    print(f"Car   : {car}")
    print("\nDrive to the start line. Recording begins when you cross it...")

    cur_lap = telem.get_int("lap_number") or 0

    while True:
        lap = telem.get_int("lap_number")
        if lap > cur_lap:
            telem.reset_lap()
            print(f"\nLap {lap} started — RECORDING!")
            cur_lap = lap
            break
        time.sleep(0.05)

    samples  = []
    start_t  = time.time()
    prev_lap = cur_lap

    while True:
        data    = telem.get_snapshot()
        elapsed = round(time.time() - start_t, 3)
        lap     = _i(data.get("lap_number") or cur_lap)

        if lap > prev_lap:
            print(f"\nLap complete! {len(samples)} samples recorded.")
            break
        prev_lap = lap

        samples.append({
            "t":              elapsed,
            "world_x":        _f(data.get("world_x")),
            "world_z":        _f(data.get("world_z")),
            "track_position": round(_f(data.get("track_position")), 3),
            "speed_kmh":      _f(data.get("speed_kmh")),
            "throttle":       _f(data.get("throttle")),
            "brake":          _f(data.get("brake")),
            "steering":       _f(data.get("steering")),
            "gear":           _i(data.get("gear")),
            "rpm":            _f(data.get("rpm")),
        })

        if len(samples) % 100 == 0:
            print(f"  {len(samples):4d} samples | "
                  f"{_f(data.get('speed_kmh')):.0f} km/h | "
                  f"pos {_f(data.get('track_position')):.1f}m | "
                  f"steer {_f(data.get('steering')):+.3f}")

        time.sleep(SAMPLE_RATE)

    if not samples:
        print("[ERROR] No samples recorded."); exit()

    has_coords = any(s["world_x"] != 0.0 or s["world_z"] != 0.0 for s in samples)
    if has_coords:
        lap_dist = sum(
            math.sqrt((samples[i]["world_x"] - samples[i-1]["world_x"])**2 +
                      (samples[i]["world_z"] - samples[i-1]["world_z"])**2)
            for i in range(1, len(samples))
        )
        dist_source = "world coordinates"
    else:
        lap_dist = sum(_f(s.get("speed_kmh", 0)) / 3.6 * SAMPLE_RATE for s in samples)
        dist_source = "speed x time (estimated)"

    safe    = telem.sanitize(track)
    out_dir = Path(LAPS_FOLDER) / safe
    out_dir.mkdir(parents=True, exist_ok=True)
    out     = out_dir / "reference_lap.json"

    if out.exists():
        print(f"[WARNING] Overwriting existing lap: {out}")

    with open(out, "w") as f:
        json.dump({
            "track_name":     track,
            "track_folder":   safe,
            "reference_car":  car,
            "telem_source":   "gt7udp",
            "sample_rate":    SAMPLE_RATE,
            "total_samples":  len(samples),
            "lap_distance_m": round(lap_dist, 1),
            "dist_source":    dist_source,
            "samples":        samples,
        }, f, indent=2)

    print(f"\n✓  Saved: {out}")
    print(f"   Track    : {track}")
    print(f"   Car      : {car}")
    print(f"   Samples  : {len(samples)}")
    print(f"   Lap dist : {lap_dist:.0f} m  ({dist_source})")
