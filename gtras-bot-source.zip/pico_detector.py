# pico_detector.py — runs on your PC
# Scans USB serial ports and identifies which Raspberry Pi Pico board is connected.
#
# Requires: pyserial
#   pip install pyserial

import tkinter as tk
from tkinter import ttk
import serial.tools.list_ports
import threading
import time

# ── Board identification ────────────────────────────────────────────────────────
# CircuitPython sets the USB product string to the board name.
# We match substrings in order — most specific first.
BOARD_SIGNATURES = [
    ("Pico 2 W",  "Pico 2 W"),
    ("Pico 2",    "Pico 2"),
    ("Pico W",    "Pico W"),
    ("Pico",      "Pico"),
]

# Adafruit / Raspberry Pi vendor IDs used by CircuitPython boards
KNOWN_VIDS = {0x239A, 0x2E8A}

BOARD_INFO = {
    "Pico":     {"chip": "RP2040", "wifi": False,  "color": "#3a7ebf"},
    "Pico W":   {"chip": "RP2040", "wifi": True,   "color": "#2a9d5c"},
    "Pico 2":   {"chip": "RP2350", "wifi": False,  "color": "#7b5ea7"},
    "Pico 2 W": {"chip": "RP2350", "wifi": True,   "color": "#c0652b"},
    "Unknown":  {"chip": "?",      "wifi": None,   "color": "#888888"},
}


def identify_board(port_info):
    """Return board name string from a ListPortInfo object, or None if not a Pico."""
    product     = (port_info.product     or "").strip()
    description = (port_info.description or "").strip()
    combined    = f"{product} {description}"

    is_known = (
        port_info.vid in KNOWN_VIDS
        or "CircuitPython" in combined
        or "Raspberry Pi"  in combined
    )
    if not is_known:
        return None

    for board_name, keyword in BOARD_SIGNATURES:
        if keyword in combined:
            return board_name

    return "Unknown"


def scan_ports():
    """Return list of (port, board_name) for all detected Pico boards."""
    results = []
    for p in serial.tools.list_ports.comports():
        board = identify_board(p)
        if board is not None:
            results.append((p.device, board))
    return results


# ── GUI ────────────────────────────────────────────────────────────────────────
class PicoDetector(tk.Tk):
    def __init__(self):
        super().__init__()
        self.title("Pico Board Detector")
        self.resizable(False, False)
        self.configure(bg="#1e1e1e")
        self._build_ui()
        self._auto_scan()

    # ── Layout ─────────────────────────────────────────────────────────────────
    def _build_ui(self):
        pad = {"padx": 16, "pady": 10}

        tk.Label(
            self, text="Raspberry Pi Pico Detector",
            font=("Segoe UI", 15, "bold"),
            bg="#1e1e1e", fg="white"
        ).pack(**pad)

        self.card_frame = tk.Frame(self, bg="#1e1e1e")
        self.card_frame.pack(fill="x", padx=16)

        self.status_var = tk.StringVar(value="Scanning…")
        self.status_label = tk.Label(
            self.card_frame,
            textvariable=self.status_var,
            font=("Segoe UI", 11),
            bg="#1e1e1e", fg="#aaaaaa"
        )
        self.status_label.pack(pady=6)

        ttk.Separator(self, orient="horizontal").pack(fill="x", padx=16, pady=4)

        bottom = tk.Frame(self, bg="#1e1e1e")
        bottom.pack(fill="x", padx=16, pady=(4, 12))

        self.scan_btn = tk.Button(
            bottom, text="↻  Scan again",
            font=("Segoe UI", 10),
            bg="#333333", fg="white",
            activebackground="#444444", activeforeground="white",
            relief="flat", padx=12, pady=5,
            command=self._manual_scan
        )
        self.scan_btn.pack(side="left")

        self.auto_var = tk.BooleanVar(value=True)
        tk.Checkbutton(
            bottom, text="Auto-scan every 3 s",
            variable=self.auto_var,
            font=("Segoe UI", 9),
            bg="#1e1e1e", fg="#aaaaaa",
            activebackground="#1e1e1e", activeforeground="white",
            selectcolor="#1e1e1e"
        ).pack(side="left", padx=12)

    # ── Card rendering ──────────────────────────────────────────────────────────
    def _clear_cards(self):
        for w in self.card_frame.winfo_children():
            w.destroy()

    def _show_status(self, text):
        self._clear_cards()
        tk.Label(
            self.card_frame, text=text,
            font=("Segoe UI", 11),
            bg="#1e1e1e", fg="#aaaaaa"
        ).pack(pady=12)

    def _render_card(self, port, board_name):
        info   = BOARD_INFO.get(board_name, BOARD_INFO["Unknown"])
        accent = info["color"]

        card = tk.Frame(self.card_frame, bg="#2a2a2a", bd=0)
        card.pack(fill="x", pady=5, ipady=8, ipadx=10)

        stripe = tk.Frame(card, bg=accent, width=6)
        stripe.pack(side="left", fill="y")

        body = tk.Frame(card, bg="#2a2a2a")
        body.pack(side="left", fill="x", expand=True, padx=10)

        tk.Label(
            body, text=board_name,
            font=("Segoe UI", 14, "bold"),
            bg="#2a2a2a", fg=accent
        ).grid(row=0, column=0, sticky="w")

        chip_text = f"Chip: {info['chip']}"
        wifi_text = ("WiFi: Yes" if info["wifi"] else
                     "WiFi: No"  if info["wifi"] is False else
                     "WiFi: ?")
        port_text = f"Port: {port}"

        for i, txt in enumerate([chip_text, wifi_text, port_text]):
            tk.Label(
                body, text=txt,
                font=("Segoe UI", 10),
                bg="#2a2a2a", fg="#cccccc"
            ).grid(row=i + 1, column=0, sticky="w")

        def copy_port(p=port):
            self.clipboard_clear()
            self.clipboard_append(p)

        tk.Button(
            body, text="Copy port",
            font=("Segoe UI", 9),
            bg=accent, fg="white",
            activebackground="#555555", activeforeground="white",
            relief="flat", padx=8, pady=3,
            command=copy_port
        ).grid(row=1, column=1, rowspan=2, padx=(20, 0), sticky="e")

        body.columnconfigure(1, weight=1)

    # ── Scan logic ──────────────────────────────────────────────────────────────
    def _do_scan(self):
        self._show_status("Scanning…")
        self.update_idletasks()

        boards = scan_ports()
        self._clear_cards()

        if not boards:
            self._show_status("No Pico board detected.\nPlug in your Pico and scan again.")
            return

        for port, board_name in boards:
            self._render_card(port, board_name)

    def _manual_scan(self):
        self.scan_btn.config(state="disabled")
        self._do_scan()
        self.scan_btn.config(state="normal")

    def _auto_scan(self):
        def _loop():
            while True:
                if self.auto_var.get():
                    self.after(0, self._do_scan)
                time.sleep(3)

        t = threading.Thread(target=_loop, daemon=True)
        t.start()


# ── Entry point ────────────────────────────────────────────────────────────────
if __name__ == "__main__":
    app = PicoDetector()
    app.mainloop()
