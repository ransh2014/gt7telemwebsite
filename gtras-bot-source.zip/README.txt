GT7 BOT — QUICK START
======================
1. pip install -r requirements.txt

2. Set your PS4/PS5 IP in gt7bot/config.py
   PS4/PS5 → Settings → Network → View Connection Status

3. Set your Pico COM port in gt7bot/config.py
   Run: python pico_detector.py  (shows board type + COM port, one click to copy)
   Or:  Device Manager → Ports → USB Serial Device (COMx)

4. Flash the Pico — see how_to_setup_pico.txt
   Copy pico/boot.py and pico/code.py to your Pico

5. Test Pico:  python gt7bot/test_pico.py
   Full bot:   python gt7bot/gui.py

Record a lap first — see how_to_record_a_lap.txt
Daytona grind setup — see how_to_daytona_grind.txt

Credits: Telemetry packet offsets and decryption by Bornhall
https://github.com/Bornhall/gt7telemetry
JSON export added by gtras.co
