# pico_test.py — Pico controller test
# Confirms the Pico is wired correctly and responding to all commands.
# Run this before the bot. GT7 does NOT need to be open.
#
# Usage: python pico_test.py

import serial
import time
import sys

PORT = "COM3"   # Change to match your Pico's COM port
BAUD = 115200

# All button names the Pico accepts (from code.py BUTTONS dict)
ALL_BUTTONS = [
    "cross", "circle", "square", "triangle",
    "l1", "r1",
    "options", "share", "ps",
    "up", "down", "left", "right",
    "l3", "r3",
]


def send(ser, msg):
    ser.write(f"{msg}\n".encode())
    time.sleep(0.05)


def tap(ser, btn, hold=0.15):
    send(ser, f"BTN:{btn}")
    print(f"  BTN:{btn}")
    time.sleep(hold)


def drive(ser, t, b, s, duration=0.5):
    send(ser, f"T:{t:.3f},B:{b:.3f},S:{s:.3f}")
    print(f"  T:{t:.3f}  B:{b:.3f}  S:{s:.3f}  ({duration}s)")
    time.sleep(duration)
    send(ser, "T:0.000,B:0.000,S:0.000")
    time.sleep(0.1)


def test_buttons(ser):
    print(f"\n[Buttons] Tapping all {len(ALL_BUTTONS)} buttons with 0.6s gap...")
    for btn in ALL_BUTTONS:
        tap(ser, btn)
        time.sleep(0.6)
    print("[Buttons] Done.\n")


def test_drive(ser):
    print("\n[Drive] Full throttle (1.0s)...")
    drive(ser, 1.0, 0.0, 0.0, 1.0)
    time.sleep(0.3)

    print("[Drive] Full brake (0.5s)...")
    drive(ser, 0.0, 1.0, 0.0, 0.5)
    time.sleep(0.3)

    print("[Drive] Full steer left (0.4s)...")
    drive(ser, 0.0, 0.0, -1.0, 0.4)
    time.sleep(0.2)

    print("[Drive] Full steer right (0.4s)...")
    drive(ser, 0.0, 0.0,  1.0, 0.4)
    time.sleep(0.2)

    print("[Drive] Half throttle + half steer right (0.5s)...")
    drive(ser, 0.5, 0.0, 0.5, 0.5)
    time.sleep(0.2)

    print("[Drive] Done.\n")


def main():
    port = input(f"COM port [{PORT}]: ").strip() or PORT
    print(f"Connecting to {port} at {BAUD}...")
    try:
        ser = serial.Serial(port, BAUD, timeout=2)
        time.sleep(1.5)   # Let Pico finish booting
        print("Connected.\n")
    except Exception as e:
        print(f"Failed: {e}")
        sys.exit(1)

    while True:
        print("── Pico Test Menu ──────────────────")
        print("  1  Test all buttons")
        print("  2  Test drive commands")
        print("  3  Test all (buttons + drive)")
        print("  4  Tap a single button")
        print("  5  Send a raw drive command")
        print("  0  Exit")
        choice = input("Choice: ").strip()

        if choice == "1":
            test_buttons(ser)

        elif choice == "2":
            test_drive(ser)

        elif choice == "3":
            test_buttons(ser)
            time.sleep(0.5)
            test_drive(ser)

        elif choice == "4":
            print(f"Valid buttons: {', '.join(ALL_BUTTONS)}")
            btn = input("Button name: ").strip().lower()
            if btn in ALL_BUTTONS:
                tap(ser, btn)
                print(f"  Sent BTN:{btn}")
            else:
                print(f"  Unknown button: {btn}")

        elif choice == "5":
            try:
                t = float(input("Throttle (0.0–1.0): ").strip())
                b = float(input("Brake    (0.0–1.0): ").strip())
                s = float(input("Steer   (-1.0–1.0): ").strip())
                d = float(input("Duration (seconds): ").strip() or "0.5")
                drive(ser, t, b, s, d)
            except ValueError:
                print("  Invalid input.")

        elif choice == "0":
            break

        else:
            print("  Invalid choice.\n")

    send(ser, "T:0.000,B:0.000,S:0.000")   # Zero outputs on exit
    ser.close()
    print("Done.")


if __name__ == "__main__":
    main()
