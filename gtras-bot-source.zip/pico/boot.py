# boot.py — runs BEFORE code.py on every Pico startup
# Must be named exactly boot.py and sit in the root of the Pico's drive
#
# CircuitPython disables the secondary serial port and gamepad HID by default.
# This file enables both before the main code runs.

import usb_cdc
import usb_hid

# Enable console (for debug prints) + data port (for PC commands)
usb_cdc.enable(console=True, data=True)

# Enable gamepad HID — PS4 will see this as a controller
usb_hid.enable((usb_hid.Device.GAMEPAD,))
