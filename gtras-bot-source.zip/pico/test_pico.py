# test_pico.py — verify your Pico / Pico W is connected and responding
#
# Usage:
#   python test_pico.py
#
# What it does:
#   1. Opens the serial port from config.py
#   2. Sends axis commands (throttle, brake, steer)
#   3. Sends every button
#   4. Tells you exactly what to watch for on PS4

import sys
import time
import serial
from config import PICO_PORT, PICO_BAUDRATE

SEP = "─" * 55

def send(port, msg):
    port.write(f"{msg}\n".encode())
    time.sleep(0.05)

def section(title):
    print(f"\n{SEP}")
    print(f"  {title}")
    print(SEP)

def pause(label, secs=1.2):
    print(f"  → {label}", end="", flush=True)
    time.sleep(secs)
    print("  ✓")

# ─────────────────────────────────────────────────────────────────────────────
print(SEP)
print("  GTRAS — Pico / Pico W Connection Test")
print(SEP)
print(f"  Port: {PICO_PORT}  |  Baud: {PICO_BAUDRATE}")
print()

# ── 1. Open serial port ──────────────────────────────────────────────────────
try:
    port = serial.Serial(PICO_PORT, PICO_BAUDRATE, timeout=2)
    print(f"✓  Serial port opened: {PICO_PORT}")
except Exception as e:
    print(f"✗  Cannot open {PICO_PORT}: {e}")
    print()
    print("  Fix checklist:")
    print("  1. Is Pico plugged into powered USB hub?")
    print("  2. Is powered hub connected to both PC and PS4?")
    print("  3. Open Device Manager → Ports (COM & LPT)")
    print(f"     Change PICO_PORT in config.py to the correct COMx number")
    sys.exit(1)

time.sleep(1.5)   # give Pico time to finish boot

# ── 2. Axis tests ────────────────────────────────────────────────────────────
section("AXIS TESTS — watch PS4 controller overlay if using DS4Windows,")
print("  or just observe GT7 / any game that shows controller input")

print("\n  Full throttle (R2 = 100%) for 1.5s...")
send(port, "T:1.000,B:0.000,S:0.000")
pause("R2 should be fully pressed", 1.5)
send(port, "T:0.000,B:0.000,S:0.000")
time.sleep(0.3)

print("\n  Full brake (L2 = 100%) for 1.5s...")
send(port, "T:0.000,B:1.000,S:0.000")
pause("L2 should be fully pressed", 1.5)
send(port, "T:0.000,B:0.000,S:0.000")
time.sleep(0.3)

print("\n  Steer left (left stick X = -50%) for 1.5s...")
send(port, "T:0.000,B:0.000,S:-0.500")
pause("Left stick should move left", 1.5)
send(port, "T:0.000,B:0.000,S:0.000")
time.sleep(0.3)

print("\n  Steer right (left stick X = +50%) for 1.5s...")
send(port, "T:0.000,B:0.000,S:0.500")
pause("Left stick should move right", 1.5)
send(port, "T:0.000,B:0.000,S:0.000")
time.sleep(0.3)

print("\n  Neutral — all axes zero")
send(port, "T:0.000,B:0.000,S:0.000")
time.sleep(0.5)

# ── 3. Button tests ──────────────────────────────────────────────────────────
section("BUTTON TESTS — watch PS4 (in GT7 menus each tap navigates)")

buttons = [
    ("cross",    "✕  Cross    — confirm / select in menus"),
    ("circle",   "○  Circle   — cancel / back"),
    ("triangle", "△  Triangle — map / reverse in some games"),
    ("square",   "□  Square   — options / hand brake"),
    ("l1",       "L1"),
    ("r1",       "R1"),
    ("up",       "D-pad Up"),
    ("down",     "D-pad Down"),
    ("left",     "D-pad Left"),
    ("right",    "D-pad Right"),
    ("options",  "OPTIONS  — pause menu"),
]

for btn, label in buttons:
    send(port, f"BTN:{btn}")
    pause(label, 0.9)

# ── 4. Cleanup ───────────────────────────────────────────────────────────────
send(port, "T:0.000,B:0.000,S:0.000")
port.close()

print()
print(SEP)
print("  Test complete.")
print()
print("  If every item above triggered on PS4 → Pico is 100% working.")
print()
print("  If NOTHING triggered:")
print("    - Make sure PS4 is ON and hub is powered")
print("    - Replug Pico into hub after plugging hub into PS4")
print("    - Wait ~5s after replug before running this script again")
print()
print("  If AXES work but BUTTONS don't (or vice versa):")
print("    - boot.py may not be on the Pico — re-copy and replug")
print(SEP)
