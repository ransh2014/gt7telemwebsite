# code.py — runs ON the Raspberry Pi Pico / Pico W / Pico 2 / Pico 2 W
# Requires boot.py to have run first
#
# All variants:  HID controller only (USB serial receives drive/button commands)
#
# Commands from PC → Pico:
#   T:0.85,B:0.00,S:-0.42\n   — drive (throttle, brake, steer)
#   BTN:cross\n                — button tap

import usb_hid
import usb_cdc
from adafruit_hid.gamepad import Gamepad
import time

gp     = Gamepad(usb_hid.devices)
serial = usb_cdc.data
buf    = b""

if serial is None:
    raise RuntimeError("usb_cdc.data is None — make sure boot.py is on the Pico")

print("GT7 Bot ready")

# ── Button map ─────────────────────────────────────────────────────────────────
BUTTONS = {
    "cross":    1,
    "circle":   2,
    "square":   3,
    "triangle": 4,
    "l1":       5,
    "r1":       6,
    "share":    9,
    "options":  10,
    "l3":       11,
    "r3":       12,
    "ps":       13,
    "up":       14,
    "down":     15,
    "left":     16,
    "right":    17,
}

# ── HID helpers ────────────────────────────────────────────────────────────────
def apply_drive(throttle, brake, steer):
    s  = int(max(-127, min(127, steer    * 127)))
    r2 = int(max(   0, min(127, throttle * 127)))
    l2 = int(max(   0, min(127, brake    * 127)))
    gp.move_joysticks(x=s, y=0, z=r2, r_z=l2)

def tap_button(name, hold=0.1):
    btn = BUTTONS.get(name.lower())
    if btn is None: return
    gp.press_buttons(btn)
    time.sleep(hold)
    gp.release_buttons(btn)

def parse_drive(line):
    try:
        parts = {}
        for chunk in line.strip().split(","):
            k, v = chunk.split(":")
            parts[k.strip()] = float(v.strip())
        t = max(0.0, min(1.0,  parts.get("T", 0.0)))
        b = max(0.0, min(1.0,  parts.get("B", 0.0)))
        s = max(-1.0, min(1.0, parts.get("S", 0.0)))
        return t, b, s
    except:
        return 0.0, 0.0, 0.0

# ── Main loop ──────────────────────────────────────────────────────────────────
while True:
    if serial.in_waiting > 0:
        buf += serial.read(serial.in_waiting)
        while b"\n" in buf:
            line, buf = buf.split(b"\n", 1)
            decoded   = line.decode("utf-8", errors="ignore").strip()
            if not decoded:
                continue
            if decoded == "PING":
                serial.write(b"PICO_OK\n")
            elif decoded.startswith("BTN:"):
                tap_button(decoded[4:])
            else:
                t, b, s = parse_drive(decoded)
                apply_drive(t, b, s)

    time.sleep(0.001)
