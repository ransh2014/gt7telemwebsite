# gt7telem.py — GT7 Live Telemetry Viewer
# Standalone tool — no bot, no Pico needed. Just telemetry + lap recording.
#
# Usage: python gt7telem.py
#
# Credits: Packet offsets and decryption method by Bornhall
#          https://github.com/Bornhall/gt7telemetry
#
# Features:
#   - Live dashboard: speed, RPM, gear, throttle, brake, tyres, fuel, lap times
#   - Record any lap to JSON with one click
#   - Export full session to JSON

import tkinter as tk
from tkinter import ttk, scrolledtext, filedialog
import threading
import time
import json
import math
from pathlib import Path
from datetime import datetime

import gt7udp as telem
from config import PS4_IP, LAPS_FOLDER, SAMPLE_RATE

# ─────────────────────────────────────────────────────────────────────────────
# Helpers
# ─────────────────────────────────────────────────────────────────────────────
def ms_to_laptime(ms):
    if ms <= 0: return "--:--.---"
    s = ms / 1000.0
    m = int(s // 60)
    s = s % 60
    return f"{m}:{s:06.3f}"

def temp_color(val, cold=60, good=80, hot=100):
    if val <= 0:   return "#555"
    if val < cold: return "#4fc3f7"
    if val < good: return "#2ecc71"
    if val < hot:  return "#f39c12"
    return "#e74c3c"

# ─────────────────────────────────────────────────────────────────────────────
# Recording state
# ─────────────────────────────────────────────────────────────────────────────
class Session:
    recording     = False
    samples       = []
    start_t       = 0.0
    cur_lap       = 0
    prev_lap      = 0
    laps_saved    = []    # list of saved lap dicts for session export

session = Session()

# ─────────────────────────────────────────────────────────────────────────────
# Main App
# ─────────────────────────────────────────────────────────────────────────────
class App(tk.Tk):
    def __init__(self):
        super().__init__()
        self.title("GT7 Telemetry")
        self.configure(bg="#0a0a12")
        self.geometry("1100x720")
        self.minsize(900, 600)
        self._build()
        self._start_telem()
        self.after(200, self._poll)

    # ── Build UI ─────────────────────────────────────────────────────────────
    def _build(self):
        BG   = "#0a0a12"
        PNL  = "#0f0f1e"
        ACC  = "#e94560"
        HI   = "#4fc3f7"
        FG   = "#c0c0e0"
        DIM  = "#555566"

        # ── Header ──
        hdr = tk.Frame(self, bg="#0f3460", pady=6)
        hdr.pack(fill="x")
        tk.Label(hdr, text="GT7 TELEMETRY", fg=ACC, bg="#0f3460",
                 font=("Consolas",14,"bold")).pack(side="left", padx=16)
        self.conn_dot = tk.Label(hdr, text="● OFFLINE", fg=DIM, bg="#0f3460",
                                  font=("Consolas",10))
        self.conn_dot.pack(side="left", padx=8)
        tk.Label(hdr, text=f"PS4: {PS4_IP}", fg=DIM, bg="#0f3460",
                 font=("Consolas",9)).pack(side="left", padx=8)

        # record / export buttons
        self.rec_btn = tk.Button(hdr, text="⏺  Record Lap",
                                  command=self._toggle_record,
                                  bg="#16213e", fg=FG, relief="flat",
                                  font=("Consolas",10,"bold"), padx=12, pady=3)
        self.rec_btn.pack(side="right", padx=6)
        tk.Button(hdr, text="💾  Export Session",
                  command=self._export_session,
                  bg="#16213e", fg=FG, relief="flat",
                  font=("Consolas",10), padx=12, pady=3
                  ).pack(side="right", padx=4)

        # ── Body: left panels + right log ──
        body = tk.Frame(self, bg=BG)
        body.pack(fill="both", expand=True, padx=8, pady=6)

        left = tk.Frame(body, bg=BG)
        left.pack(side="left", fill="both", expand=True)
        right = tk.Frame(body, bg=BG, width=260)
        right.pack(side="right", fill="y", padx=(6,0))
        right.pack_propagate(False)

        # ── Speed + Gear ──
        sg = tk.Frame(left, bg=PNL, pady=8)
        sg.pack(fill="x", pady=(0,4))
        self.speed_lbl = tk.Label(sg, text="0", fg=HI, bg=PNL,
                                   font=("Consolas",64,"bold"))
        self.speed_lbl.pack(side="left", padx=20)
        tk.Label(sg, text="km/h", fg=DIM, bg=PNL,
                 font=("Consolas",14)).pack(side="left", pady=(24,0))
        self.gear_lbl = tk.Label(sg, text="N", fg="#f39c12", bg=PNL,
                                  font=("Consolas",64,"bold"))
        self.gear_lbl.pack(side="right", padx=20)
        tk.Label(sg, text="gear", fg=DIM, bg=PNL,
                 font=("Consolas",14)).pack(side="right", pady=(24,0))

        # ── Lap info ──
        lap_f = tk.Frame(left, bg=PNL, pady=6)
        lap_f.pack(fill="x", pady=(0,4))
        for attr, label, col in [
            ("lap_lbl",  "LAP",   FG),
            ("cur_lbl",  "CURRENT", HI),
            ("best_lbl", "BEST",  "#2ecc71"),
            ("last_lbl", "LAST",  FG),
            ("pos_lbl",  "POS",   FG),
        ]:
            col_f = tk.Frame(lap_f, bg=PNL)
            col_f.pack(side="left", expand=True)
            tk.Label(col_f, text=label, fg=DIM, bg=PNL,
                     font=("Consolas",8)).pack()
            lbl = tk.Label(col_f, text="—", fg=col, bg=PNL,
                           font=("Consolas",13,"bold"))
            lbl.pack()
            setattr(self, attr, lbl)

        # ── RPM bar ──
        def bar_row(parent, label, attr_var, attr_lbl, fg_color):
            f = tk.Frame(parent, bg=BG)
            f.pack(fill="x", pady=2)
            tk.Label(f, text=label, fg=DIM, bg=BG,
                     font=("Consolas",9), width=8).pack(side="left", padx=4)
            var = tk.DoubleVar()
            pb  = ttk.Progressbar(f, variable=var, maximum=100,
                                   length=300, mode="determinate")
            pb.pack(side="left", fill="x", expand=True, padx=4)
            lbl = tk.Label(f, text="0", fg=fg_color, bg=BG,
                           font=("Consolas",10), width=10)
            lbl.pack(side="left")
            setattr(self, attr_var, var)
            setattr(self, attr_lbl, lbl)

        bar_row(left, "RPM",      "rpm_var",  "rpm_lbl",  "#e74c3c")
        bar_row(left, "THROTTLE", "thr_var",  "thr_lbl",  "#2ecc71")
        bar_row(left, "BRAKE",    "brk_var",  "brk_lbl",  "#e74c3c")

        # ── Tyre temps ──
        tyre_f = tk.LabelFrame(left, text=" TYRES ", fg=ACC, bg=BG,
                                font=("Consolas",9))
        tyre_f.pack(fill="x", pady=6, padx=2)
        for label, t_attr, s_attr in [
            ("FL","tyre_fl","slip_fl"), ("FR","tyre_fr","slip_fr"),
            ("RL","tyre_rl","slip_rl"), ("RR","tyre_rr","slip_rr")
        ]:
            col_f = tk.Frame(tyre_f, bg=BG)
            col_f.pack(side="left", expand=True, padx=8, pady=4)
            tk.Label(col_f, text=label, fg=DIM, bg=BG,
                     font=("Consolas",9)).pack()
            t_lbl = tk.Label(col_f, text="—°C", fg=HI, bg=BG,
                             font=("Consolas",13,"bold"))
            t_lbl.pack()
            s_lbl = tk.Label(col_f, text="slip —", fg=DIM, bg=BG,
                             font=("Consolas",8))
            s_lbl.pack()
            setattr(self, t_attr, t_lbl)
            setattr(self, s_attr, s_lbl)

        # ── Engine / misc ──
        eng_f = tk.LabelFrame(left, text=" ENGINE & MISC ", fg=ACC, bg=BG,
                               font=("Consolas",9))
        eng_f.pack(fill="x", pady=4, padx=2)
        self._eng_labels = {}
        eng_items = [
            ("FUEL",     "fuel_lbl"),
            ("BOOST",    "boost_lbl"),
            ("OIL °C",   "oil_lbl"),
            ("WATER °C", "water_lbl"),
            ("RIDE mm",  "ride_lbl"),
        ]
        for i, (title, attr) in enumerate(eng_items):
            col_f = tk.Frame(eng_f, bg=BG)
            col_f.pack(side="left", expand=True, padx=8, pady=4)
            tk.Label(col_f, text=title, fg=DIM, bg=BG,
                     font=("Consolas",8)).pack()
            lbl = tk.Label(col_f, text="—", fg=FG, bg=BG,
                           font=("Consolas",12,"bold"))
            lbl.pack()
            setattr(self, attr, lbl)

        # ── RIGHT: Log ──
        tk.Label(right, text="LOG", fg=ACC, bg=BG,
                 font=("Consolas",9,"bold")).pack(anchor="w", pady=(0,2))
        self.log = scrolledtext.ScrolledText(right, bg="#050510", fg="#00ff88",
                                              font=("Consolas",8), relief="flat")
        self.log.pack(fill="both", expand=True)

    # ── Telemetry start ───────────────────────────────────────────────────────
    def _start_telem(self):
        threading.Thread(target=self._connect_thread, daemon=True).start()

    def _connect_thread(self):
        self.log_msg(f"Connecting to {PS4_IP}...")
        result = telem.wait_for_connection(timeout=60)
        if result is not None:
            self.log_msg("Connected! Telemetry live.")
        else:
            self.log_msg("Timeout — check PS4_IP in config.py")

    # ── Poll ──────────────────────────────────────────────────────────────────
    def _poll(self):
        d = telem.get_snapshot()
        ok = telem.is_connected()

        # Connection dot
        self.conn_dot.config(
            text="● LIVE" if ok else "● OFFLINE",
            fg="#2ecc71" if ok else "#555"
        )

        if not ok:
            self.after(250, self._poll); return

        spd  = float(d.get("speed_kmh") or 0)
        gear = int(d.get("gear") or 0)
        rpm  = float(d.get("rpm") or 0)
        mrpm = float(d.get("max_rpm") or 1) or 1
        thr  = float(d.get("throttle") or 0)
        brk  = float(d.get("brake") or 0)

        self.speed_lbl.config(text=f"{spd:.0f}")
        self.gear_lbl.config(text=str(gear) if gear > 0 else "N")

        self.rpm_var.set(min(100, rpm / mrpm * 100))
        self.rpm_lbl.config(text=f"{rpm:.0f}")
        self.thr_var.set(thr * 100)
        self.thr_lbl.config(text=f"{thr*100:.0f}%")
        self.brk_var.set(brk * 100)
        self.brk_lbl.config(text=f"{brk*100:.0f}%")

        # Lap info
        cur_lap = int(d.get("lap_number") or 0)
        tot_lap = int(d.get("total_laps") or 0)
        cur_pos = int(d.get("current_position") or 0)
        tot_pos = int(d.get("total_positions") or 0)
        best_ms = int(d.get("best_lap_ms") or -1)
        last_ms = int(d.get("last_lap_ms") or -1)

        self.lap_lbl.config(text=f"{cur_lap}/{tot_lap}")
        self.best_lbl.config(text=ms_to_laptime(best_ms))
        self.last_lbl.config(text=ms_to_laptime(last_ms))
        self.pos_lbl.config(text=f"{cur_pos}/{tot_pos}" if cur_pos else "—")

        # Tyres
        for attr, temp_key, slip_key in [
            ("tyre_fl","tyre_temp_fl","tyre_slip_fl"),
            ("tyre_fr","tyre_temp_fr","tyre_slip_fr"),
            ("tyre_rl","tyre_temp_rl","tyre_slip_rl"),
            ("tyre_rr","tyre_temp_rr","tyre_slip_rr"),
        ]:
            tmp = float(d.get(temp_key) or 0)
            slp = float(d.get(slip_key) or 1)
            lbl = getattr(self, attr)
            lbl.config(text=f"{tmp:.0f}°C" if tmp > 0 else "—°C",
                       fg=temp_color(tmp))
            getattr(self, slip_key.replace("tyre_","")+"")\
                .config(text=f"slip {slp:.2f}")

        # Engine misc
        fuel_r = float(d.get("fuel_remaining") or 0)
        fuel_c = float(d.get("fuel_capacity") or 0)
        is_ev  = bool(d.get("is_ev"))
        fuel_str = f"{fuel_r:.1f}kWh" if is_ev else f"{fuel_r:.1f}L"
        if fuel_c > 0:
            fuel_str += f"/{fuel_c:.0f}"

        self.fuel_lbl.config(text=fuel_str)
        boost = float(d.get("boost") or 0)
        self.boost_lbl.config(text=f"{boost:.2f}" if boost > 0 else "—")
        self.oil_lbl.config(text=f"{float(d.get('oil_temp') or 0):.0f}")
        self.water_lbl.config(text=f"{float(d.get('water_temp') or 0):.0f}")
        self.ride_lbl.config(text=f"{float(d.get('ride_height_mm') or 0):.0f}")

        # Recording
        if session.recording:
            self._record_sample(d)

        self.after(100, self._poll)   # 10 Hz UI

    # ── Fix slip label reference ──────────────────────────────────────────────
    def __getattr__(self, name):
        # handles slip_fl, slip_fr etc dynamically — fallback
        raise AttributeError(name)

    # ── Logging ───────────────────────────────────────────────────────────────
    def log_msg(self, msg):
        self.after(0, self._log_append, msg)

    def _log_append(self, msg):
        ts = time.strftime("%H:%M:%S")
        self.log.insert("end", f"[{ts}] {msg}\n")
        self.log.see("end")

    # ── Record ────────────────────────────────────────────────────────────────
    def _toggle_record(self):
        if session.recording:
            self._stop_record()
        else:
            self._start_record()

    def _start_record(self):
        session.recording  = True
        session.samples    = []
        session.start_t    = time.time()
        session.cur_lap    = telem.get_int("lap_number")
        session.prev_lap   = session.cur_lap
        telem.reset_lap()
        self.rec_btn.config(text="⏹  Stop Recording", bg="#e94560")
        self.log_msg("Recording started — cross start line to begin lap")

    def _stop_record(self):
        session.recording = False
        self.rec_btn.config(text="⏺  Record Lap", bg="#16213e")
        if session.samples:
            self._save_lap(session.samples)
        else:
            self.log_msg("No samples recorded.")

    def _record_sample(self, d):
        lap = int(d.get("lap_number") or session.prev_lap)
        # Lap complete
        if lap > session.prev_lap and session.samples:
            self.log_msg(f"Lap complete — {len(session.samples)} samples")
            self._save_lap(list(session.samples))
            session.samples = []
            session.start_t = time.time()
            telem.reset_lap()
        session.prev_lap = lap

        def _f(k): 
            try: return round(float(d.get(k) or 0), 4)
            except: return 0.0
        def _i(k):
            try: return int(d.get(k) or 0)
            except: return 0

        session.samples.append({
            "t":              round(time.time() - session.start_t, 3),
            "world_x":        _f("world_x"),
            "world_z":        _f("world_z"),
            "track_position": _f("track_position"),
            "speed_kmh":      _f("speed_kmh"),
            "throttle":       _f("throttle"),
            "brake":          _f("brake"),
            "steering":       _f("steering"),
            "gear":           _i("gear"),
            "rpm":            _f("rpm"),
            "tyre_temp_fl":   _f("tyre_temp_fl"),
            "tyre_temp_fr":   _f("tyre_temp_fr"),
            "tyre_temp_rl":   _f("tyre_temp_rl"),
            "tyre_temp_rr":   _f("tyre_temp_rr"),
            "fuel_remaining": _f("fuel_remaining"),
            "tyre_slip_fl":   _f("tyre_slip_fl"),
            "tyre_slip_fr":   _f("tyre_slip_fr"),
            "tyre_slip_rl":   _f("tyre_slip_rl"),
            "tyre_slip_rr":   _f("tyre_slip_rr"),
        })

    def _save_lap(self, samples):
        import math as _math
        has_coords = any(s.get("world_x", 0) != 0 for s in samples)
        if has_coords:
            lap_dist = sum(
                _math.sqrt((samples[i]["world_x"]-samples[i-1]["world_x"])**2 +
                           (samples[i]["world_z"]-samples[i-1]["world_z"])**2)
                for i in range(1, len(samples))
            )
        else:
            lap_dist = sum(s.get("speed_kmh",0)/3.6*SAMPLE_RATE for s in samples)

        ts    = datetime.now().strftime("%Y%m%d_%H%M%S")
        fname = f"lap_{ts}.json"
        Path(LAPS_FOLDER).mkdir(parents=True, exist_ok=True)
        out = Path(LAPS_FOLDER) / fname
        data = {
            "recorded_at":    ts,
            "lap_distance_m": round(lap_dist, 1),
            "total_samples":  len(samples),
            "samples":        samples,
        }
        with open(out, "w") as f:
            json.dump(data, f, indent=2)
        session.laps_saved.append(data)
        self.log_msg(f"Saved: {fname}  ({lap_dist:.0f}m, {len(samples)} samples)")

    # ── Export session ────────────────────────────────────────────────────────
    def _export_session(self):
        if not session.laps_saved:
            self.log_msg("No laps recorded this session.")
            return
        path = filedialog.asksaveasfilename(
            defaultextension=".json",
            filetypes=[("JSON","*.json")],
            initialfile=f"gt7_session_{datetime.now().strftime('%Y%m%d_%H%M%S')}.json"
        )
        if not path: return
        with open(path, "w") as f:
            json.dump({
                "exported_at": datetime.now().isoformat(),
                "laps":        session.laps_saved,
            }, f, indent=2)
        self.log_msg(f"Session exported: {Path(path).name}")


# ─────────────────────────────────────────────────────────────────────────────
if __name__ == "__main__":
    app = App()
    app.mainloop()
