# config.py — all settings in one place

# ── PS4 IP address ────────────────────────────────────────────────────────────
# Find it: PS4 → Settings → Network → View Connection Status
PS4_IP = "192.168.1.X"   # ← change this to your PS4's IP

SAMPLE_RATE = 0.05            # seconds between samples when recording (20 Hz)

# ── Folders ───────────────────────────────────────────────────────────────────
LAPS_FOLDER = "laps"      # laps/<track>/reference_lap.json

# ── SimHub property keys (kept for reference / any legacy callers) ────────────
PROPS = {
    "track_name":     "DataCorePlugin.GameData.TrackName",
    "car_name":       "DataCorePlugin.GameData.CarModel",
    "car_class":      "DataCorePlugin.GameData.CarClass",
    "lap_number":     "DataCorePlugin.GameData.CurrentLap",
    "track_position": "DataCorePlugin.GameData.TrackPositionPercent",
    "speed_kmh":      "DataCorePlugin.GameData.SpeedKmh",
    "throttle":       "DataCorePlugin.GameData.Throttle",
    "brake":          "DataCorePlugin.GameData.Brake",
    "steering":       "DataCorePlugin.GameData.Steer",
    "gear":           "DataCorePlugin.GameData.Gear",
    "rpm":            "DataCorePlugin.GameData.Rpms",
}
