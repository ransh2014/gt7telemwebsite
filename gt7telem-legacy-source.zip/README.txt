GT7 TELEMETRY — QUICK START
============================
1. pip install -r requirements.txt

2. Open config.py — set PS4_IP to your PS4/PS5 IP address
   PS4/PS5 → Settings → Network → View Connection Status

3. python gt7telem.py

No SimHub. No hardware. Just your PC and PS4/PS5 on the same WiFi.

Features:
  - Live speed, RPM, gear, throttle, brake
  - Tyre temps + slip ratios
  - Fuel, boost, oil/water temp
  - Lap times, race position
  - Record laps to JSON
  - Export full session to JSON

Credits: Packet offsets and decryption by Bornhall
https://github.com/Bornhall/gt7telemetry
